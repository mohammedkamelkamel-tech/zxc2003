package com.alkamel.distribution;

import android.app.Activity;
import android.content.Intent;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;
import java.security.MessageDigest;
import java.util.Locale;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.alkamel.distribution.database.DatabaseHelper;
import com.alkamel.distribution.model.DailySummary;
import com.alkamel.distribution.util.DateUtils;

public class MainActivity extends Activity {
    private DatabaseHelper dbHelper;
    private TextView tvTodayDate;
    private TextView tvStatC100, tvStatC200, tvStatC250, tvStatC500;
    private TextView tvTotalCards, tvTotalAmount, tvVisitedShops;
    private CancellationSignal fingerprintSignal;
    private AlertDialog fingerprintDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = DatabaseHelper.getInstance(this);
        SharedPreferences prefs = getSharedPreferences("app_security", MODE_PRIVATE);
        if (!prefs.contains("pin_hash")) showSetPinDialog(); else showUnlockDialog();
    }

    private String hashPin(String pin) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(pin.getBytes("UTF-8"));
            StringBuilder out = new StringBuilder(); for (byte b : digest) out.append(String.format(Locale.US, "%02x", b & 0xff)); return out.toString();
        } catch (Exception e) { return pin; }
    }

    private EditText pinField(String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); return e;
    }

    private void showSetPinDialog() {
        final EditText first = pinField("أنشئ كلمة مرور رقمية من 4 أرقام أو أكثر");
        new AlertDialog.Builder(this).setTitle("تأمين التطبيق").setMessage("أنشئ كلمة مرور لفتح التطبيق. يمكنك استخدام البصمة لاحقًا إذا كان جهازك يدعمها.").setView(first).setCancelable(false)
          .setPositiveButton("حفظ كلمة المرور", new DialogInterface.OnClickListener(){ public void onClick(DialogInterface d,int w){
            String pin=first.getText().toString(); if(pin.length()<4){ Toast.makeText(MainActivity.this,"كلمة المرور يجب أن تكون 4 أرقام على الأقل",Toast.LENGTH_LONG).show(); showSetPinDialog(); return; }
            SharedPreferences p=getSharedPreferences("app_security",MODE_PRIVATE); p.edit().putString("pin_hash",hashPin(pin)).apply(); initUI();
          }}).show();
    }

    private void showUnlockDialog() {
        final EditText pin=pinField("أدخل كلمة المرور");
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle("فتح التطبيق").setMessage("أدخل كلمة المرور أو استخدم البصمة إن كانت مفعلة على جهازك.").setView(pin).setCancelable(false)
          .setPositiveButton("فتح",null).setNegativeButton("بصمة الإصبع",null);
        final AlertDialog dialog=b.create(); dialog.setOnShowListener(new DialogInterface.OnShowListener(){ public void onShow(DialogInterface di){
          dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String saved=getSharedPreferences("app_security",MODE_PRIVATE).getString("pin_hash",""); if(hashPin(pin.getText().toString()).equals(saved)){dialog.dismiss();initUI();}else{pin.setError("كلمة المرور غير صحيحة");}});
          dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v->tryFingerprint(dialog));
        }}); dialog.show();
    }

    private void tryFingerprint(final AlertDialog unlockDialog) {
        if (Build.VERSION.SDK_INT < 23) {
            Toast.makeText(this, "البصمة غير مدعومة على هذا الإصدار؛ استخدم كلمة المرور", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            android.hardware.fingerprint.FingerprintManager fm =
                (android.hardware.fingerprint.FingerprintManager) getSystemService(FINGERPRINT_SERVICE);
            if (fm == null || !fm.isHardwareDetected()) {
                Toast.makeText(this, "هذا الجهاز لا يحتوي على مستشعر بصمة متاح؛ استخدم كلمة المرور", Toast.LENGTH_LONG).show();
                return;
            }
            if (!fm.hasEnrolledFingerprints()) {
                Toast.makeText(this, "سجّل بصمة أولاً من إعدادات الهاتف ثم حاول مجدداً", Toast.LENGTH_LONG).show();
                return;
            }

            // FingerprintManager on older Android versions does not display its own prompt.
            // Show a clear prompt and keep it visible while the sensor is listening.
            TextView message = new TextView(this);
            message.setText("ضع إصبعك المسجّل على مستشعر البصمة في الهاتف\n\nإذا لم تعمل البصمة، اضغط إلغاء واستخدم كلمة المرور.");
            message.setTextSize(17);
            message.setPadding(36, 28, 36, 28);
            message.setGravity(Gravity.CENTER);
            fingerprintDialog = new AlertDialog.Builder(this)
                .setTitle("التحقق بالبصمة")
                .setView(message)
                .setNegativeButton("إلغاء", (d, w) -> cancelFingerprint())
                .setCancelable(false)
                .create();
            fingerprintDialog.show();
            fingerprintSignal = new CancellationSignal();

            fm.authenticate(null, fingerprintSignal, 0,
                new android.hardware.fingerprint.FingerprintManager.AuthenticationCallback() {
                    @Override public void onAuthenticationSucceeded(android.hardware.fingerprint.FingerprintManager.AuthenticationResult result) {
                        runOnUiThread(() -> {
                            dismissFingerprintDialog();
                            if (!isFinishing()) {
                                unlockDialog.dismiss();
                                initUI();
                            }
                        });
                    }
                    @Override public void onAuthenticationFailed() {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "لم يتم التعرف على البصمة؛ حاول مرة أخرى", Toast.LENGTH_SHORT).show());
                    }
                    @Override public void onAuthenticationHelp(int helpCode, CharSequence helpString) {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            helpString, Toast.LENGTH_SHORT).show());
                    }
                    @Override public void onAuthenticationError(int code, CharSequence msg) {
                        runOnUiThread(() -> {
                            dismissFingerprintDialog();
                            if (code != 5) { // ERROR_CANCELED is expected when the user cancels.
                                Toast.makeText(MainActivity.this,
                                    "تعذر التحقق بالبصمة: " + msg + "؛ يمكنك فتح التطبيق بكلمة المرور", Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }, null);
        } catch (Exception e) {
            dismissFingerprintDialog();
            Toast.makeText(this, "تعذر تشغيل البصمة. استخدم كلمة المرور لفتح التطبيق", Toast.LENGTH_LONG).show();
        }
    }

    private void cancelFingerprint() {
        if (fingerprintSignal != null) {
            try { fingerprintSignal.cancel(); } catch (Exception ignored) { }
            fingerprintSignal = null;
        }
        dismissFingerprintDialog();
    }

    private void dismissFingerprintDialog() {
        if (fingerprintDialog != null && fingerprintDialog.isShowing()) fingerprintDialog.dismiss();
        fingerprintDialog = null;
        fingerprintSignal = null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (tvTodayDate != null) refreshTodayStats();
        // Ensure the daily 01:00 backup alarm remains scheduled.
        BackupScheduler.scheduleDaily(this);
    }

    private void initUI() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scrollView.setBackgroundColor(0xFF0F172A); // slate-900

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 40);
        scrollView.addView(root);

        // Header with App Icon and Title
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 10, 0, 24);

        ImageView ivLogo = new ImageView(this);
        ivLogo.setImageResource(R.mipmap.ic_launcher);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(120, 120);
        logoParams.setMargins(0, 0, 20, 0);
        ivLogo.setLayoutParams(logoParams);
        header.addView(ivLogo);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        
        TextView tvTitle = new TextView(this);
        tvTitle.setText("الكامل للتوزيع والتحصيل");
        tvTitle.setTextSize(22);
        tvTitle.setTextColor(0xFFF8FAFC);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        titleBox.addView(tvTitle);

        tvTodayDate = new TextView(this);
        tvTodayDate.setTextSize(14);
        tvTodayDate.setTextColor(0xFF94A3B8);
        titleBox.addView(tvTodayDate);

        header.addView(titleBox);
        root.addView(header);

        // Prominent PDF Invoice Button
        Button btnPdf = new Button(this);
        btnPdf.setText("📄 إنشاء فاتورة اليوم PDF");
        btnPdf.setTextSize(18);
        btnPdf.setTextColor(Color.WHITE);
        btnPdf.setBackgroundColor(0xFF2563EB); // blue-600
        btnPdf.setPadding(20, 24, 20, 24);
        LinearLayout.LayoutParams btnPdfParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnPdfParams.setMargins(0, 10, 0, 24);
        btnPdf.setLayoutParams(btnPdfParams);
        btnPdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ReportActivity.class);
                i.putExtra("DATE", DateUtils.getTodayDate());
                startActivity(i);
            }
        });
        root.addView(btnPdf);

        // Today Summary Card
        LinearLayout summaryCard = new LinearLayout(this);
        summaryCard.setOrientation(LinearLayout.VERTICAL);
        summaryCard.setBackgroundColor(0xFF1E293B);
        summaryCard.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, 24);
        summaryCard.setLayoutParams(cardParams);

        TextView tvSummaryHeader = new TextView(this);
        tvSummaryHeader.setText("📊 ملخص توزيع وتحصيل اليوم");
        tvSummaryHeader.setTextSize(16);
        tvSummaryHeader.setTextColor(0xFFFBBF24); // gold
        tvSummaryHeader.setTypeface(null, android.graphics.Typeface.BOLD);
        summaryCard.addView(tvSummaryHeader);

        // 4 cards in a row
        LinearLayout cardsRow = new LinearLayout(this);
        cardsRow.setOrientation(LinearLayout.HORIZONTAL);
        cardsRow.setPadding(0, 16, 0, 16);
        cardsRow.setWeightSum(4);

        tvStatC100 = createCardBox(cardsRow, "100 ريال", 0xFFEF4444);
        tvStatC200 = createCardBox(cardsRow, "200 ريال", 0xFF8B5CF6);
        tvStatC250 = createCardBox(cardsRow, "250 ريال", 0xFF10B981);
        tvStatC500 = createCardBox(cardsRow, "500 ريال", 0xFF38BDF8);
        summaryCard.addView(cardsRow);

        // Totals Row
        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        statsRow.setWeightSum(3);

        tvTotalCards = createStatBox(statsRow, "إجمالي الكروت", "0", 0xFF38BDF8);
        tvTotalAmount = createStatBox(statsRow, "إجمالي التحصيل", "0 ر.ي", 0xFF34D399);
        tvVisitedShops = createStatBox(statsRow, "محلات تمت زيارتها", "0", 0xFFA78BFA);
        summaryCard.addView(statsRow);

        root.addView(summaryCard);

        // Quick Action Buttons Grid
        root.addView(createSectionTitle("⚡ العمليات السريعة"));

        LinearLayout rowActions1 = new LinearLayout(this);
        rowActions1.setOrientation(LinearLayout.HORIZONTAL);
        rowActions1.setWeightSum(2);
        createActionButton(rowActions1, "📦 توزيع كروت", 0xFF059669, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DistributionActivity.class));
            }
        });
        createActionButton(rowActions1, "💰 تحصيل مالي", 0xFFD97706, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CollectionActivity.class));
            }
        });
        root.addView(rowActions1);

        LinearLayout rowActions2 = new LinearLayout(this);
        rowActions2.setOrientation(LinearLayout.HORIZONTAL);
        rowActions2.setWeightSum(2);
        createActionButton(rowActions2, "🏪 إدارة المحلات", 0xFF4F46E5, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ShopsActivity.class));
            }
        });
        createActionButton(rowActions2, "📜 سجل العمليات", 0xFF0284C7, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, HistoryActivity.class));
            }
        });
        root.addView(rowActions2);

        LinearLayout rowActions3 = new LinearLayout(this);
        rowActions3.setOrientation(LinearLayout.HORIZONTAL);
        rowActions3.setWeightSum(2);
        createActionButton(rowActions3, "📈 التقارير", 0xFF7C3AED, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ReportActivity.class));
            }
        });
        createActionButton(rowActions3, "💾 النسخ الاحتياطي", 0xFF475569, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, BackupActivity.class));
            }
        });
        root.addView(rowActions3);

        Button btnCustody = new Button(this);
        btnCustody.setText("📦 الكروت التي في عهدتي");
        btnCustody.setTextSize(17); btnCustody.setTextColor(Color.WHITE); btnCustody.setBackgroundColor(0xFF0E7490);
        btnCustody.setOnClickListener(new View.OnClickListener(){ @Override public void onClick(View v){ startActivity(new Intent(MainActivity.this, CustodyActivity.class)); }});
        root.addView(btnCustody);

        setContentView(scrollView);
    }

    private TextView createCardBox(LinearLayout parent, String title, int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(color);
        box.setPadding(8, 12, 8, 12);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        params.setMargins(4, 0, 4, 0);
        box.setLayoutParams(params);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(11);
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setGravity(Gravity.CENTER);
        box.addView(tvTitle);

        TextView tvValue = new TextView(this);
        tvValue.setText("0");
        tvValue.setTextSize(16);
        tvValue.setTextColor(Color.WHITE);
        tvValue.setTypeface(null, android.graphics.Typeface.BOLD);
        tvValue.setGravity(Gravity.CENTER);
        box.addView(tvValue);

        parent.addView(box);
        return tvValue;
    }

    private TextView createStatBox(LinearLayout parent, String title, String defVal, int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(4, 10, 4, 10);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        box.setLayoutParams(params);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(12);
        tvTitle.setTextColor(0xFF94A3B8);
        tvTitle.setGravity(Gravity.CENTER);
        box.addView(tvTitle);

        TextView tvValue = new TextView(this);
        tvValue.setText(defVal);
        tvValue.setTextSize(16);
        tvValue.setTextColor(color);
        tvValue.setTypeface(null, android.graphics.Typeface.BOLD);
        tvValue.setGravity(Gravity.CENTER);
        box.addView(tvValue);

        parent.addView(box);
        return tvValue;
    }

    private void createActionButton(LinearLayout parent, String title, int bgColor, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(title);
        btn.setTextSize(15);
        btn.setTextColor(Color.WHITE);
        btn.setBackgroundColor(bgColor);
        btn.setPadding(16, 20, 16, 20);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        params.setMargins(6, 6, 6, 6);
        btn.setLayoutParams(params);
        btn.setOnClickListener(listener);
        parent.addView(btn);
    }

    private TextView createSectionTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setTextColor(0xFFF8FAFC);
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        tv.setPadding(0, 10, 0, 10);
        return tv;
    }

    private void refreshTodayStats() {
        String today = DateUtils.getTodayDate();
        tvTodayDate.setText("تاريخ اليوم: " + today);
        DailySummary summary = dbHelper.getDailySummary(today);

        tvStatC100.setText(String.valueOf(summary.totalCard100));
        tvStatC200.setText(String.valueOf(summary.totalCard200));
        tvStatC250.setText(String.valueOf(summary.totalCard250));
        tvStatC500.setText(String.valueOf(summary.totalCard500));

        tvTotalCards.setText(String.valueOf(summary.getTotalCards()));
        tvTotalAmount.setText(String.format(java.util.Locale.US, "%,.0f", summary.totalCollected) + " ريال");
        tvVisitedShops.setText(String.valueOf(summary.visitedShopsCount));
    }
}
