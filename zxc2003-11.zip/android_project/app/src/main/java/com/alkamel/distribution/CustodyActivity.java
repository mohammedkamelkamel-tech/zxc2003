package com.alkamel.distribution;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.alkamel.distribution.database.DatabaseHelper;

public class CustodyActivity extends Activity {
    private DatabaseHelper db;
    private EditText[] inputs = new EditText[4];
    private TextView tvCurrent;
    private final String[] labels = {"فئة 100 ريال", "فئة 200 ريال", "فئة 250 ريال", "فئة 500 ريال"};
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); db=DatabaseHelper.getInstance(this); setTitle("الكروت التي في عهدتي");
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(0xFF0F172A);
        LinearLayout root = new LinearLayout(this); root.setPadding(24,24,24,32); root.setOrientation(LinearLayout.VERTICAL); scroll.addView(root);
        TextView title = new TextView(this); title.setText("📦 الكروت التي في عهدتي"); title.setTextSize(22); title.setTextColor(Color.WHITE); title.setTypeface(null,1); root.addView(title);
        TextView hint = new TextView(this); hint.setText("هذا القسم خاص بالعامل لمتابعة الكروت الموجودة في عهدته فقط، ولا يظهر في الفواتير أو تقارير التحصيل والتوزيع. أدخل هنا الكروت الجديدة التي استلمتها؛ ستُضاف إلى الرصيد المتبقي، وتُخصم الكميات الموزعة تلقائيًا بعد حفظ التوزيع."); hint.setTextColor(0xFF93C5FD); hint.setPadding(0,12,0,18); root.addView(hint);
        int[] stock=db.getCustodyStock();
        for(int i=0;i<4;i++){ TextView l=new TextView(this); l.setText(labels[i] + " — المتبقي حاليًا: " + stock[i]); l.setTextColor(0xFFFBBF24); l.setPadding(0,10,0,4); root.addView(l); EditText e=new EditText(this); e.setText("0"); e.setHint("عدد الكروت الجديدة المستلمة"); e.setInputType(2); e.setTextColor(Color.WHITE); e.setHintTextColor(0xFF94A3B8); e.setBackgroundColor(0xFF1E293B); e.setPadding(14,12,14,12); inputs[i]=e; root.addView(e); }
        Button save=new Button(this); save.setText("إضافة الكروت المستلمة للعهدة"); save.setOnClickListener(v -> saveStock()); root.addView(save);
        tvCurrent=new TextView(this); tvCurrent.setTextColor(0xFF34D399); tvCurrent.setTextSize(18); tvCurrent.setPadding(0,24,0,8); root.addView(tvCurrent); refreshCurrent();
        setContentView(scroll);
    }
    private void saveStock(){ try { int[] a=new int[4]; for(int i=0;i<4;i++){String s=inputs[i].getText().toString().trim(); a[i]=s.isEmpty()?0:Integer.parseInt(s); if(a[i]<0) throw new Exception();} if(a[0]+a[1]+a[2]+a[3]==0){Toast.makeText(this,"أدخل عدد الكروت المستلمة على الأقل في فئة واحدة",Toast.LENGTH_LONG).show();return;} if(db.addCustodyStock(a[0],a[1],a[2],a[3])){Toast.makeText(this,"تمت إضافة الكروت إلى العهدة",Toast.LENGTH_LONG).show(); for(EditText e:inputs)e.setText("0"); refreshCurrent();} else Toast.makeText(this,"تعذر إضافة الكروت",Toast.LENGTH_LONG).show(); } catch(Exception ex){Toast.makeText(this,"أدخل أعدادًا صحيحة غير سالبة",Toast.LENGTH_LONG).show();} }
    private void refreshCurrent(){int[] a=db.getCustodyStock();tvCurrent.setText("المتبقي في عهدتك الآن\n100 ريال: "+a[0]+"\n200 ريال: "+a[1]+"\n250 ريال: "+a[2]+"\n500 ريال: "+a[3]+"\n\nهذه الأرصدة للعامل فقط ولا تُضاف إلى الفاتورة.");}
}
