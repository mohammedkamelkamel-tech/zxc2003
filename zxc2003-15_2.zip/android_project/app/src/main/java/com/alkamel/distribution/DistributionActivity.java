package com.alkamel.distribution;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.alkamel.distribution.database.DatabaseHelper;
import com.alkamel.distribution.model.Operation;
import com.alkamel.distribution.model.Shop;
import com.alkamel.distribution.util.DateUtils;

import java.util.ArrayList;
import java.util.List;

public class DistributionActivity extends Activity {
    private DatabaseHelper dbHelper;
    private Spinner spShops;
    private List<Shop> shopsList;
    private EditText etC100, etC200, etC250, etC500;
    private EditText etCollectionAmount;
    private EditText etNotes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = DatabaseHelper.getInstance(this);
        setTitle("تسجيل عملية توزيع كروت");
        initUI();
    }

    private void initUI() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scrollView.setBackgroundColor(0xFF0F172A);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 40);
        scrollView.addView(root);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("📦 توزيع كروت جديدة على المحل");
        tvTitle.setTextSize(20);
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(tvTitle);

        // Shop Selection
        TextView tvShopLabel = new TextView(this);
        tvShopLabel.setText("اختر المحل:");
        tvShopLabel.setTextColor(0xFF94A3B8);
        tvShopLabel.setPadding(0, 16, 0, 8);
        root.addView(tvShopLabel);

        spShops = new Spinner(this);
        spShops.setBackgroundColor(0xFF1E293B);
        spShops.setPadding(12, 12, 12, 12);
        root.addView(spShops);

        loadShopsSpinner();

        // 4 Fixed Categories in order: 100, 200, 250, 500
        TextView tvOrderNotice = new TextView(this);
        tvOrderNotice.setText("ترتيب الفئات: 100 - 200 - 250 - 500 ريال (مسموح إدخال 0)");
        tvOrderNotice.setTextColor(0xFFFBBF24);
        tvOrderNotice.setTextSize(13);
        tvOrderNotice.setPadding(0, 20, 0, 12);
        root.addView(tvOrderNotice);

        etC100 = createCardInput(root, "فئة 100 ريال", 0xFFEF4444);
        etC200 = createCardInput(root, "فئة 200 ريال", 0xFF8B5CF6);
        etC250 = createCardInput(root, "فئة 250 ريال", 0xFF10B981);
        etC500 = createCardInput(root, "فئة 500 ريال", 0xFF38BDF8);

        // Optional Collection in same operation
        TextView tvColLabel = new TextView(this);
        tvColLabel.setText("مبلغ التحصيل (اختياري - اتركه 0 إذا لم يتم تحصيل):");
        tvColLabel.setTextColor(0xFF94A3B8);
        tvColLabel.setPadding(0, 20, 0, 8);
        root.addView(tvColLabel);

        etCollectionAmount = new EditText(this);
        etCollectionAmount.setHint("0 ريال");
        etCollectionAmount.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etCollectionAmount.setTextColor(Color.WHITE);
        etCollectionAmount.setBackgroundColor(0xFF1E293B);
        etCollectionAmount.setPadding(16, 16, 16, 16);
        root.addView(etCollectionAmount);

        // Notes
        TextView tvNotesLabel = new TextView(this);
        tvNotesLabel.setText("ملاحظات العملية (اختياري):");
        tvNotesLabel.setTextColor(0xFF94A3B8);
        tvNotesLabel.setPadding(0, 16, 0, 8);
        root.addView(tvNotesLabel);

        etNotes = new EditText(this);
        etNotes.setHint("أي ملاحظات خاصة...");
        etNotes.setTextColor(Color.WHITE);
        etNotes.setBackgroundColor(0xFF1E293B);
        etNotes.setPadding(16, 16, 16, 16);
        root.addView(etNotes);

        // Submit Button
        Button btnSave = new Button(this);
        btnSave.setText("💾 حفظ عملية التوزيع");
        btnSave.setTextSize(18);
        btnSave.setTextColor(Color.WHITE);
        btnSave.setBackgroundColor(0xFF059669);
        btnSave.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnParams.setMargins(0, 30, 0, 20);
        btnSave.setLayoutParams(btnParams);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDistribution();
            }
        });
        root.addView(btnSave);

        Button btnUndo = new Button(this);
        btnUndo.setText("↩ تراجع عن الإدخال الحالي / مسح الحقول");
        btnUndo.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            etC100.setText("0"); etC200.setText("0"); etC250.setText("0"); etC500.setText("0");
            etCollectionAmount.setText(""); etNotes.setText("");
            Toast.makeText(DistributionActivity.this, "تم التراجع عن الإدخال غير المحفوظ", Toast.LENGTH_SHORT).show();
        }});
        root.addView(btnUndo);

        setContentView(scrollView);
    }

    private EditText createCardInput(LinearLayout parent, String title, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, 6, 0, 6);

        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(color);
        label.setTextSize(15);
        label.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        label.setLayoutParams(lp);
        row.addView(label);

        EditText et = new EditText(this);
        et.setHint("0");
        et.setText("0");
        et.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        et.setTextColor(Color.WHITE);
        et.setBackgroundColor(0xFF1E293B);
        et.setGravity(Gravity.CENTER);
        et.setPadding(12, 12, 12, 12);
        LinearLayout.LayoutParams etP = new LinearLayout.LayoutParams(200, ViewGroup.LayoutParams.WRAP_CONTENT);
        et.setLayoutParams(etP);
        row.addView(et);

        parent.addView(row);
        return et;
    }

    private void loadShopsSpinner() {
        shopsList = dbHelper.getAllShops(null, true);
        List<String> names = new ArrayList<String>();
        if (shopsList.isEmpty()) {
            names.add("لا توجد محلات نشطة - يرجى إضافة محل أولاً");
        } else {
            for (Shop s : shopsList) {
                names.add(s.getName());
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, names);
        spShops.setAdapter(adapter);
    }

    private void saveDistribution() {
        if (shopsList.isEmpty()) {
            Toast.makeText(this, "يرجى إضافة محل أولاً من شاشة إدارة المحلات", Toast.LENGTH_SHORT).show();
            return;
        }
        final int selectedIdx = spShops.getSelectedItemPosition();
        if (selectedIdx < 0 || selectedIdx >= shopsList.size()) {
            Toast.makeText(this, "يرجى اختيار محل صحيح", Toast.LENGTH_SHORT).show();
            return;
        }
        final Shop selectedShop = shopsList.get(selectedIdx);
        final int c100 = parseCount(etC100);
        final int c200 = parseCount(etC200);
        final int c250 = parseCount(etC250);
        final int c500 = parseCount(etC500);
        if (c100 < 0 || c200 < 0 || c250 < 0 || c500 < 0) {
            Toast.makeText(this, "لا يمكن إدخال عدد سالب من الكروت", Toast.LENGTH_SHORT).show();
            return;
        }
        final int totalCards = c100 + c200 + c250 + c500;
        final double colAmount;
        try {
            String str = etCollectionAmount.getText().toString().trim();
            colAmount = str.isEmpty() ? 0.0 : Double.parseDouble(str);
        } catch (Exception e) {
            Toast.makeText(this, "مبلغ التحصيل المدخل غير صالح", Toast.LENGTH_SHORT).show();
            return;
        }
        if (colAmount < 0) {
            Toast.makeText(this, "لا يمكن إدخال مبلغ تحصيل سالب", Toast.LENGTH_SHORT).show();
            return;
        }
        if (totalCards == 0 && colAmount <= 0) {
            Toast.makeText(this, "يرجى إدخال عدد الكروت أو مبلغ التحصيل", Toast.LENGTH_SHORT).show();
            return;
        }
        String summary = "المحل: " + selectedShop.getName() + "\n\n" +
                "فئة 100 ريال: " + c100 + " كرت\n" +
                "فئة 200 ريال: " + c200 + " كرت\n" +
                "فئة 250 ريال: " + c250 + " كرت\n" +
                "فئة 500 ريال: " + c500 + " كرت\n\n" +
                "إجمالي الكروت: " + totalCards + "\n" +
                "مبلغ التحصيل: " + String.format(java.util.Locale.US, "%,.0f", colAmount) + " ريال";
        new AlertDialog.Builder(this)
                .setTitle("مراجعة وتأكيد عملية التوزيع")
                .setMessage(summary)
                .setNegativeButton("تراجع وتعديل", null)
                .setPositiveButton("موافق — حفظ العملية", (dialog, which) -> persistDistribution(selectedShop, c100, c200, c250, c500, colAmount, totalCards))
                .show();
    }

    private void persistDistribution(Shop selectedShop, int c100, int c200, int c250, int c500, double colAmount, int totalCards) {
        Operation op = new Operation();
        op.setShopId(selectedShop.getId());
        op.setShopName(selectedShop.getName());
        op.setDate(DateUtils.getTodayDate());
        op.setTime(DateUtils.getCurrentTime());
        op.setCard100(c100);
        op.setCard200(c200);
        op.setCard250(c250);
        op.setCard500(c500);
        op.setCollectedAmount(colAmount);
        op.setNotes(etNotes.getText().toString().trim());
        if (totalCards > 0 && colAmount > 0) op.setType("BOTH");
        else if (totalCards > 0) op.setType("DISTRIBUTION");
        else op.setType("COLLECTION");
        long savedId = dbHelper.insertOperation(op);
        if (savedId < 0) {
            Toast.makeText(this, "الرصيد في العهدة لا يكفي لهذه الكمية. افتح قسم الكروت التي في عهدتي وحدّث الرصيد أولاً.", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "تم حفظ العملية بنجاح! إجمالي الكروت: " + totalCards, Toast.LENGTH_LONG).show();
        finish();
    }

    private int parseCount(EditText et) {
        try {
            String s = et.getText().toString().trim();
            return s.isEmpty() ? 0 : Integer.parseInt(s);
        } catch (Exception e) {
            return 0;
        }
    }
}
