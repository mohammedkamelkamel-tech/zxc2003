package com.alkamel.distribution.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.alkamel.distribution.model.DailySummary;
import com.alkamel.distribution.model.Operation;
import com.alkamel.distribution.model.Shop;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "alkamel_distribution.db";
    private static final int DATABASE_VERSION = 2;

    public static final String TABLE_SHOPS = "shops";
    public static final String COL_SHOP_ID = "id";
    public static final String COL_SHOP_NAME = "name";
    public static final String COL_SHOP_OWNER = "owner_name";
    public static final String COL_SHOP_PHONE = "phone";
    public static final String COL_SHOP_ADDRESS = "address";
    public static final String COL_SHOP_NOTES = "notes";
    public static final String COL_SHOP_ACTIVE = "is_active";
    public static final String COL_SHOP_CREATED = "created_at";

    public static final String TABLE_OPERATIONS = "operations";
    public static final String COL_OP_ID = "id";
    public static final String COL_OP_SHOP_ID = "shop_id";
    public static final String COL_OP_SHOP_NAME = "shop_name";
    public static final String COL_OP_DATE = "date";
    public static final String COL_OP_TIME = "time";
    public static final String COL_OP_TYPE = "type";
    public static final String COL_OP_C100 = "card_100";
    public static final String COL_OP_C200 = "card_200";
    public static final String COL_OP_C250 = "card_250";
    public static final String COL_OP_C500 = "card_500";
    public static final String COL_OP_AMOUNT = "collected_amount";
    public static final String COL_OP_NOTES = "notes";
    public static final String COL_OP_CREATED = "created_at";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createShops = "CREATE TABLE " + TABLE_SHOPS + " (" +
                COL_SHOP_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_SHOP_NAME + " TEXT NOT NULL, " +
                COL_SHOP_OWNER + " TEXT, " +
                COL_SHOP_PHONE + " TEXT, " +
                COL_SHOP_ADDRESS + " TEXT, " +
                COL_SHOP_NOTES + " TEXT, " +
                COL_SHOP_ACTIVE + " INTEGER DEFAULT 1, " +
                COL_SHOP_CREATED + " INTEGER)";

        String createOps = "CREATE TABLE " + TABLE_OPERATIONS + " (" +
                COL_OP_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_OP_SHOP_ID + " INTEGER, " +
                COL_OP_SHOP_NAME + " TEXT NOT NULL, " +
                COL_OP_DATE + " TEXT NOT NULL, " +
                COL_OP_TIME + " TEXT NOT NULL, " +
                COL_OP_TYPE + " TEXT NOT NULL, " +
                COL_OP_C100 + " INTEGER DEFAULT 0, " +
                COL_OP_C200 + " INTEGER DEFAULT 0, " +
                COL_OP_C250 + " INTEGER DEFAULT 0, " +
                COL_OP_C500 + " INTEGER DEFAULT 0, " +
                COL_OP_AMOUNT + " REAL DEFAULT 0.0, " +
                COL_OP_NOTES + " TEXT, " +
                COL_OP_CREATED + " INTEGER)";

        db.execSQL(createShops);
        db.execSQL(createOps);
        db.execSQL("CREATE TABLE custody_stock (id INTEGER PRIMARY KEY CHECK(id=1), c100 INTEGER NOT NULL DEFAULT 0, c200 INTEGER NOT NULL DEFAULT 0, c250 INTEGER NOT NULL DEFAULT 0, c500 INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("INSERT INTO custody_stock(id,c100,c200,c250,c500) VALUES(1,0,0,0,0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS custody_stock (id INTEGER PRIMARY KEY CHECK(id=1), c100 INTEGER NOT NULL DEFAULT 0, c200 INTEGER NOT NULL DEFAULT 0, c250 INTEGER NOT NULL DEFAULT 0, c500 INTEGER NOT NULL DEFAULT 0)");
            db.execSQL("INSERT OR IGNORE INTO custody_stock(id,c100,c200,c250,c500) VALUES(1,0,0,0,0)");
        }
    }

    public synchronized int[] getCustodyStock() {
        int[] stock = new int[]{0,0,0,0};
        Cursor c = getReadableDatabase().rawQuery("SELECT c100,c200,c250,c500 FROM custody_stock WHERE id=1", null);
        if (c.moveToFirst()) for (int i=0;i<4;i++) stock[i]=c.getInt(i);
        c.close();
        return stock;
    }

    public synchronized boolean setCustodyStock(int c100, int c200, int c250, int c500) {
        if (c100 < 0 || c200 < 0 || c250 < 0 || c500 < 0) return false;
        ContentValues v = new ContentValues(); v.put("c100",c100); v.put("c200",c200); v.put("c250",c250); v.put("c500",c500);
        return getWritableDatabase().update("custody_stock",v,"id=1",null)==1;
    }

    /** Add newly received cards to the worker's custody balance without replacing the remaining balance. */
    public synchronized boolean addCustodyStock(int c100, int c200, int c250, int c500) {
        if (c100 < 0 || c200 < 0 || c250 < 0 || c500 < 0) return false;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.execSQL("UPDATE custody_stock SET c100=c100+?, c200=c200+?, c250=c250+?, c500=c500+? WHERE id=1",
                    new Object[]{c100, c200, c250, c500});
            db.setTransactionSuccessful();
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            db.endTransaction();
        }
    }


    // --- Shops CRUD ---
    public long insertShop(Shop shop) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_SHOP_NAME, shop.getName());
        cv.put(COL_SHOP_OWNER, shop.getOwnerName());
        cv.put(COL_SHOP_PHONE, shop.getPhone());
        cv.put(COL_SHOP_ADDRESS, shop.getAddress());
        cv.put(COL_SHOP_NOTES, shop.getNotes());
        cv.put(COL_SHOP_ACTIVE, shop.isActive() ? 1 : 0);
        cv.put(COL_SHOP_CREATED, shop.getCreatedAt());
        long id = db.insert(TABLE_SHOPS, null, cv);
        shop.setId(id);
        return id;
    }

    public int updateShop(Shop shop) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_SHOP_NAME, shop.getName());
        cv.put(COL_SHOP_OWNER, shop.getOwnerName());
        cv.put(COL_SHOP_PHONE, shop.getPhone());
        cv.put(COL_SHOP_ADDRESS, shop.getAddress());
        cv.put(COL_SHOP_NOTES, shop.getNotes());
        cv.put(COL_SHOP_ACTIVE, shop.isActive() ? 1 : 0);
        return db.update(TABLE_SHOPS, cv, COL_SHOP_ID + " = ?", new String[]{String.valueOf(shop.getId())});
    }

    public List<Shop> getAllShops(String searchQuery, boolean onlyActive) {
        List<Shop> list = new ArrayList<Shop>();
        SQLiteDatabase db = getReadableDatabase();
        StringBuilder query = new StringBuilder("SELECT * FROM " + TABLE_SHOPS + " WHERE 1=1 ");
        List<String> args = new ArrayList<String>();

        if (onlyActive) {
            query.append(" AND " + COL_SHOP_ACTIVE + " = 1 ");
        }

        if (searchQuery != null && !searchQuery.trim().isEmpty()) {
            query.append(" AND " + COL_SHOP_NAME + " LIKE ? ");
            args.add("%" + searchQuery.trim() + "%");
        }

        query.append(" ORDER BY " + COL_SHOP_NAME + " COLLATE LOCALIZED ASC");
        Cursor c = db.rawQuery(query.toString(), args.toArray(new String[0]));
        if (c.moveToFirst()) {
            do {
                Shop s = new Shop();
                s.setId(c.getLong(c.getColumnIndexOrThrow(COL_SHOP_ID)));
                s.setName(c.getString(c.getColumnIndexOrThrow(COL_SHOP_NAME)));
                s.setOwnerName(c.getString(c.getColumnIndexOrThrow(COL_SHOP_OWNER)));
                s.setPhone(c.getString(c.getColumnIndexOrThrow(COL_SHOP_PHONE)));
                s.setAddress(c.getString(c.getColumnIndexOrThrow(COL_SHOP_ADDRESS)));
                s.setNotes(c.getString(c.getColumnIndexOrThrow(COL_SHOP_NOTES)));
                s.setActive(c.getInt(c.getColumnIndexOrThrow(COL_SHOP_ACTIVE)) == 1);
                s.setCreatedAt(c.getLong(c.getColumnIndexOrThrow(COL_SHOP_CREATED)));
                list.add(s);
            } while (c.moveToNext());
        }
        c.close();
        return list;
    }

    // --- Operations CRUD ---
    public long insertOperation(Operation op) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_OP_SHOP_ID, op.getShopId());
        cv.put(COL_OP_SHOP_NAME, op.getShopName());
        cv.put(COL_OP_DATE, op.getDate());
        cv.put(COL_OP_TIME, op.getTime());
        cv.put(COL_OP_TYPE, op.getType());
        cv.put(COL_OP_C100, op.getCard100());
        cv.put(COL_OP_C200, op.getCard200());
        cv.put(COL_OP_C250, op.getCard250());
        cv.put(COL_OP_C500, op.getCard500());
        cv.put(COL_OP_AMOUNT, op.getCollectedAmount());
        cv.put(COL_OP_NOTES, op.getNotes());
        cv.put(COL_OP_CREATED, op.getCreatedAt());
        boolean hasDistribution = op.getCard100()+op.getCard200()+op.getCard250()+op.getCard500() > 0;
        db.beginTransaction();
        long id = -1;
        try {
            if (hasDistribution) {
                Cursor stockCursor = db.rawQuery("SELECT c100,c200,c250,c500 FROM custody_stock WHERE id=1", null);
                int[] stock = new int[4];
                boolean found = stockCursor.moveToFirst();
                if (found) for (int i=0;i<4;i++) stock[i]=stockCursor.getInt(i);
                stockCursor.close();
                if (!found || stock[0] < op.getCard100() || stock[1] < op.getCard200() || stock[2] < op.getCard250() || stock[3] < op.getCard500()) {
                    return -1;
                }
                ContentValues sv = new ContentValues();
                sv.put("c100", stock[0]-op.getCard100()); sv.put("c200", stock[1]-op.getCard200());
                sv.put("c250", stock[2]-op.getCard250()); sv.put("c500", stock[3]-op.getCard500());
                db.update("custody_stock", sv, "id=1", null);
            }
            id = db.insert(TABLE_OPERATIONS, null, cv);
            if (id != -1) db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        op.setId(id);
        return id;
    }

    public int deleteOperation(long opId) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_OPERATIONS, COL_OP_ID + " = ?", new String[]{String.valueOf(opId)});
    }

    public List<Operation> getOperations(String date, String shopQuery, String typeFilter) {
        List<Operation> list = new ArrayList<Operation>();
        SQLiteDatabase db = getReadableDatabase();
        StringBuilder query = new StringBuilder("SELECT * FROM " + TABLE_OPERATIONS + " WHERE 1=1 ");
        List<String> args = new ArrayList<String>();

        if (date != null && !date.trim().isEmpty()) {
            query.append(" AND " + COL_OP_DATE + " = ? ");
            args.add(date.trim());
        }

        if (shopQuery != null && !shopQuery.trim().isEmpty()) {
            query.append(" AND " + COL_OP_SHOP_NAME + " LIKE ? ");
            args.add("%" + shopQuery.trim() + "%");
        }

        if (typeFilter != null && !typeFilter.equals("ALL") && !typeFilter.trim().isEmpty()) {
            query.append(" AND " + COL_OP_TYPE + " = ? ");
            args.add(typeFilter.trim());
        }

        query.append(" ORDER BY " + COL_OP_ID + " DESC");
        Cursor c = db.rawQuery(query.toString(), args.toArray(new String[0]));
        if (c.moveToFirst()) {
            do {
                Operation op = new Operation();
                op.setId(c.getLong(c.getColumnIndexOrThrow(COL_OP_ID)));
                op.setShopId(c.getLong(c.getColumnIndexOrThrow(COL_OP_SHOP_ID)));
                op.setShopName(c.getString(c.getColumnIndexOrThrow(COL_OP_SHOP_NAME)));
                op.setDate(c.getString(c.getColumnIndexOrThrow(COL_OP_DATE)));
                op.setTime(c.getString(c.getColumnIndexOrThrow(COL_OP_TIME)));
                op.setType(c.getString(c.getColumnIndexOrThrow(COL_OP_TYPE)));
                op.setCard100(c.getInt(c.getColumnIndexOrThrow(COL_OP_C100)));
                op.setCard200(c.getInt(c.getColumnIndexOrThrow(COL_OP_C200)));
                op.setCard250(c.getInt(c.getColumnIndexOrThrow(COL_OP_C250)));
                op.setCard500(c.getInt(c.getColumnIndexOrThrow(COL_OP_C500)));
                op.setCollectedAmount(c.getDouble(c.getColumnIndexOrThrow(COL_OP_AMOUNT)));
                op.setNotes(c.getString(c.getColumnIndexOrThrow(COL_OP_NOTES)));
                op.setCreatedAt(c.getLong(c.getColumnIndexOrThrow(COL_OP_CREATED)));
                list.add(op);
            } while (c.moveToNext());
        }
        c.close();
        return list;
    }

    public DailySummary getDailySummary(String date) {
        DailySummary summary = new DailySummary();
        List<Operation> ops = getOperations(date, null, "ALL");
        Set<String> uniqueShops = new HashSet<String>();

        for (Operation op : ops) {
            summary.totalCard100 += op.getCard100();
            summary.totalCard200 += op.getCard200();
            summary.totalCard250 += op.getCard250();
            summary.totalCard500 += op.getCard500();
            summary.totalCollected += op.getCollectedAmount();

            if (op.getShopName() != null && !op.getShopName().trim().isEmpty()) {
                uniqueShops.add(op.getShopName().trim());
            }
        }
        summary.visitedShopsCount = uniqueShops.size();
        return summary;
    }

    // --- Backup & Restore JSON ---
    public String exportBackupJSON() throws JSONException {
        JSONObject root = new JSONObject();
        root.put("appName", "الكامل للتوزيع والتحصيل");
        root.put("version", 1);
        root.put("exportedAt", System.currentTimeMillis());

        JSONArray shopsArray = new JSONArray();
        List<Shop> shops = getAllShops(null, false);
        for (Shop s : shops) {
            shopsArray.put(s.toJSON());
        }
        root.put("shops", shopsArray);

        JSONArray opsArray = new JSONArray();
        List<Operation> ops = getOperations(null, null, "ALL");
        for (Operation op : ops) {
            opsArray.put(op.toJSON());
        }
        root.put("operations", opsArray);

        return root.toString(2);
    }

    public boolean importBackupJSON(String jsonString) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            JSONObject root = new JSONObject(jsonString);
            if (!root.has("shops") || !root.has("operations")) {
                return false;
            }

            db.delete(TABLE_SHOPS, null, null);
            db.delete(TABLE_OPERATIONS, null, null);

            JSONArray shopsArray = root.getJSONArray("shops");
            for (int i = 0; i < shopsArray.length(); i++) {
                Shop s = Shop.fromJSON(shopsArray.getJSONObject(i));
                ContentValues cv = new ContentValues();
                if (s.getId() > 0) cv.put(COL_SHOP_ID, s.getId());
                cv.put(COL_SHOP_NAME, s.getName());
                cv.put(COL_SHOP_OWNER, s.getOwnerName());
                cv.put(COL_SHOP_PHONE, s.getPhone());
                cv.put(COL_SHOP_ADDRESS, s.getAddress());
                cv.put(COL_SHOP_NOTES, s.getNotes());
                cv.put(COL_SHOP_ACTIVE, s.isActive() ? 1 : 0);
                cv.put(COL_SHOP_CREATED, s.getCreatedAt());
                db.insert(TABLE_SHOPS, null, cv);
            }

            JSONArray opsArray = root.getJSONArray("operations");
            for (int i = 0; i < opsArray.length(); i++) {
                Operation op = Operation.fromJSON(opsArray.getJSONObject(i));
                ContentValues cv = new ContentValues();
                if (op.getId() > 0) cv.put(COL_OP_ID, op.getId());
                cv.put(COL_OP_SHOP_ID, op.getShopId());
                cv.put(COL_OP_SHOP_NAME, op.getShopName());
                cv.put(COL_OP_DATE, op.getDate());
                cv.put(COL_OP_TIME, op.getTime());
                cv.put(COL_OP_TYPE, op.getType());
                cv.put(COL_OP_C100, op.getCard100());
                cv.put(COL_OP_C200, op.getCard200());
                cv.put(COL_OP_C250, op.getCard250());
                cv.put(COL_OP_C500, op.getCard500());
                cv.put(COL_OP_AMOUNT, op.getCollectedAmount());
                cv.put(COL_OP_NOTES, op.getNotes());
                cv.put(COL_OP_CREATED, op.getCreatedAt());
                db.insert(TABLE_OPERATIONS, null, cv);
            }

            db.setTransactionSuccessful();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.endTransaction();
        }
    }
}
