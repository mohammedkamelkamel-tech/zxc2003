package com.alkamel.distribution;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.alkamel.distribution.database.DatabaseHelper;
import com.alkamel.distribution.model.Operation;
import com.alkamel.distribution.model.Shop;
import com.alkamel.distribution.util.DateUtils;

import java.util.ArrayList;
import java.util.List;

public class CollectionActivity extends Activity {
    private DatabaseHelper dbHelper;
    private Spinner spShops;
    private List<Shop> shopsList;
    private EditText etAmount;
    private EditText etNotes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = DatabaseHelper.getInstance(this);
        setTitle("تسجيل عملية تحصيل مالي");
        initUI();
    }

    private void initUI() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scrollView.setBackgroundColor(0xFF0F172A);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 40);
        scrollView.addView(root);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("💰 تحصيل مبالغ مالية مستقل");
        tvTitle.setTextSize(20);
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(tvTitle);

        TextView tvSub = new TextView(this);
        tvSub.setText("التحصيل مستقل تماماً عن التوزيع - سداد ديون سابقة أو دفعات نقدية دون توزيع كروت");
        tvSub.setTextColor(0xFF38BDF8);
        tvSub.setTextSize(13);
        tvSub.setPadding(0, 8, 0, 20);
        root.addView(tvSub);

        // Shop Selection
        TextView tvShopLabel = new TextView(this);
        tvShopLabel.setText("اختر المحل:");
        tvShopLabel.setTextColor(0xFF94A3B8);
        tvShopLabel.setPadding(0, 8, 0, 8);
        root.addView(tvShopLabel);

        spShops = new Spinner(this);
        spShops.setBackgroundColor(0xFF1E293B);
        spShops.setPadding(12, 12, 12, 12);
        root.addView(spShops);

        loadShopsSpinner();

        // Amount Input
        TextView tvAmountLabel = new TextView(this);
        tvAmountLabel.setText("المبلغ المحصل فعلياً (ريال):");
        tvAmountLabel.setTextColor(0xFF34D399);
        tvAmountLabel.setTextSize(16);
        tvAmountLabel.setTypeface(null, android.graphics.Typeface.BOLD);
        tvAmountLabel.setPadding(0, 24, 0, 8);
        root.addView(tvAmountLabel);

        etAmount = new EditText(this);
        etAmount.setHint("مثال: 50000");
        etAmount.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etAmount.setTextColor(Color.WHITE);
        etAmount.setBackgroundColor(0xFF1E293B);
        etAmount.setTextSize(20);
        etAmount.setPadding(16, 16, 16, 16);
        root.addView(etAmount);

        // Notes
        TextView tvNotesLabel = new TextView(this);
        tvNotesLabel.setText("ملاحظات (مثلاً: دفعة سابقة، سداد دين، كاش):");
        tvNotesLabel.setTextColor(0xFF94A3B8);
        tvNotesLabel.setPadding(0, 16, 0, 8);
        root.addView(tvNotesLabel);

        etNotes = new EditText(this);
        etNotes.setHint("ملاحظات التحصيل...");
        etNotes.setTextColor(Color.WHITE);
        etNotes.setBackgroundColor(0xFF1E293B);
        etNotes.setPadding(16, 16, 16, 16);
        root.addView(etNotes);

        // Save Button
        Button btnSave = new Button(this);
        btnSave.setText("💰 حفظ مبلغ التحصيل");
        btnSave.setTextSize(18);
        btnSave.setTextColor(Color.WHITE);
        btnSave.setBackgroundColor(0xFFD97706); // amber-600
        btnSave.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnParams.setMargins(0, 30, 0, 20);
        btnSave.setLayoutParams(btnParams);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCollection();
            }
        });
        root.addView(btnSave);

        Button btnUndo = new Button(this);
        btnUndo.setText("↩ تراجع عن الإدخال الحالي / مسح الحقول");
        btnUndo.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            etAmount.setText(""); etNotes.setText("");
            Toast.makeText(CollectionActivity.this, "تم التراجع عن الإدخال غير المحفوظ", Toast.LENGTH_SHORT).show();
        }});
        root.addView(btnUndo);

        setContentView(scrollView);
    }

    private void loadShopsSpinner() {
        shopsList = dbHelper.getAllShops(null, true);
        List<String> names = new ArrayList<String>();
        if (shopsList.isEmpty()) {
            names.add("لا توجد محلات نشطة");
        } else {
            for (Shop s : shopsList) {
                names.add(s.getName());
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, names) {
            private TextView makeShopRow(int position, View convertView, boolean dropdown) {
                TextView row = convertView instanceof TextView ? (TextView) convertView : new TextView(CollectionActivity.this);
                String shopName = getItem(position);
                String number = toArabicNumber(position + 1);
                row.setText(number + "  |  " + shopName + "  💵💰");
                row.setTextSize(dropdown ? 17 : 18);
                row.setTextColor(Color.WHITE);
                row.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                row.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
                row.setTextDirection(View.TEXT_DIRECTION_RTL);
                row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                row.setPadding(18, dropdown ? 15 : 17, 18, dropdown ? 15 : 17);
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(dropdown ? (position % 2 == 0 ? 0xFF1E293B : 0xFF26364D) : 0xFF1E293B);
                bg.setCornerRadius(14);
                bg.setStroke(1, 0xFF3B82F6);
                row.setBackground(bg);
                row.setMinHeight(dropdown ? 54 : 58);
                return row;
            }

            @Override public View getView(int position, View convertView, ViewGroup parent) {
                return makeShopRow(position, convertView, false);
            }

            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                return makeShopRow(position, convertView, true);
            }
        };
        spShops.setAdapter(adapter);
    }

    private String toArabicNumber(int value) {
        String western = String.valueOf(value);
        return western.replace('0', '٠').replace('1', '١').replace('2', '٢')
                .replace('3', '٣').replace('4', '٤').replace('5', '٥')
                .replace('6', '٦').replace('7', '٧').replace('8', '٨').replace('9', '٩');
    }

    private void saveCollection() {
        if (shopsList.isEmpty()) {
            Toast.makeText(this, "يرجى إضافة محل أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        String strAmount = etAmount.getText().toString().trim();
        if (strAmount.isEmpty()) {
            Toast.makeText(this, "يرجى إدخال المبلغ المحصل", Toast.LENGTH_SHORT).show();
            return;
        }
        final double amount;
        try {
            amount = Double.parseDouble(strAmount);
        } catch (Exception e) {
            Toast.makeText(this, "المبلغ المدخل غير صالح", Toast.LENGTH_SHORT).show();
            return;
        }
        if (amount <= 0) {
            Toast.makeText(this, "يجب أن يكون المبلغ أكبر من صفر", Toast.LENGTH_SHORT).show();
            return;
        }
        int selectedIdx = spShops.getSelectedItemPosition();
        if (selectedIdx < 0 || selectedIdx >= shopsList.size()) {
            Toast.makeText(this, "يرجى اختيار محل صحيح", Toast.LENGTH_SHORT).show();
            return;
        }
        final Shop selectedShop = shopsList.get(selectedIdx);
        String summary = "المحل: " + selectedShop.getName() + "\n\n" +
                "مبلغ التحصيل: " + String.format(java.util.Locale.US, "%,.0f", amount) + " ريال\n\n" +
                "ملاحظات: " + (etNotes.getText().toString().trim().isEmpty() ? "لا توجد" : etNotes.getText().toString().trim());
        new AlertDialog.Builder(this)
                .setTitle("مراجعة وتأكيد التحصيل")
                .setMessage(summary)
                .setNegativeButton("تراجع وتعديل", null)
                .setPositiveButton("موافق — حفظ التحصيل", (dialog, which) -> persistCollection(selectedShop, amount))
                .show();
    }

    private void persistCollection(Shop selectedShop, double amount) {
        Operation op = new Operation();
        op.setShopId(selectedShop.getId());
        op.setShopName(selectedShop.getName());
        op.setDate(DateUtils.getTodayDate());
        op.setTime(DateUtils.getCurrentTime());
        op.setType("COLLECTION");
        op.setCollectedAmount(amount);
        op.setNotes(etNotes.getText().toString().trim());
        long savedId = dbHelper.insertOperation(op);
        if (savedId < 0) {
            Toast.makeText(this, "تعذر حفظ التحصيل، حاول مرة أخرى", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "تم حفظ مبلغ التحصيل: " + String.format(java.util.Locale.US, "%,.0f", amount) + " ريال", Toast.LENGTH_LONG).show();
        finish();
    }
}
