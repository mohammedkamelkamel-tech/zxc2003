package com.alkamel.distribution;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.alkamel.distribution.database.DatabaseHelper;
import com.alkamel.distribution.model.DailySummary;
import com.alkamel.distribution.model.Operation;
import com.alkamel.distribution.util.DateUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ReportActivity extends Activity {
    private DatabaseHelper dbHelper;
    private String selectedDate;
    private TextView tvReportDate;
    private LinearLayout containerDistribution;
    private LinearLayout containerCollection;
    private TextView tvTotal100, tvTotal200, tvTotal250, tvTotal500;
    private byte[] pendingDistributionPdf;
    private TextView tvGrandCards, tvGrandAmount, tvVisitedShops;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = DatabaseHelper.getInstance(this);

        String d = getIntent().getStringExtra("DATE");
        selectedDate = (d != null && !d.isEmpty()) ? d : DateUtils.getTodayDate();

        setTitle("فاتورة اليوم الرسمية");
        initUI();
    }

    private void initUI() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scrollView.setBackgroundColor(0xFF0F172A);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 20, 20, 40);
        scrollView.addView(root);

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(0xFF1E293B);
        header.setPadding(16, 16, 16, 16);

        tvReportDate = new TextView(this);
        tvReportDate.setText("تقرير تاريخ: " + selectedDate);
        tvReportDate.setTextColor(0xFFFBBF24);
        tvReportDate.setTextSize(17);
        tvReportDate.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        tvReportDate.setLayoutParams(hp);
        header.addView(tvReportDate);

        Button btnDate = new Button(this);
        btnDate.setText("📅 التاريخ");
        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });
        header.addView(btnDate);
        root.addView(header);

        // Main Action: Generate & Share Invoice
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setWeightSum(2);
        actionRow.setPadding(0, 16, 0, 16);

        Button btnGeneratePdf = new Button(this);
        btnGeneratePdf.setText("📄 فاتورة اليوم PDF (تحصيل + توزيع)");
        btnGeneratePdf.setTextColor(Color.WHITE);
        btnGeneratePdf.setBackgroundColor(0xFF2563EB);
        LinearLayout.LayoutParams bp1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        bp1.setMargins(0, 0, 6, 0);
        btnGeneratePdf.setLayoutParams(bp1);
        btnGeneratePdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportDistributionPdf();
            }
        });
        actionRow.addView(btnGeneratePdf);

        Button btnShare = new Button(this);
        btnShare.setText("📲 مشاركة الفاتورة");
        btnShare.setTextColor(Color.WHITE);
        btnShare.setBackgroundColor(0xFF059669);
        LinearLayout.LayoutParams bp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        bp2.setMargins(6, 0, 0, 0);
        btnShare.setLayoutParams(bp2);
        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareReportText();
            }
        });
        actionRow.addView(btnShare);
        root.addView(actionRow);

        Button btnCopyDistribution = new Button(this);
        btnCopyDistribution.setText("📋 نسخ جميع تفاصيل التوزيع");
        btnCopyDistribution.setTextColor(Color.WHITE);
        btnCopyDistribution.setBackgroundColor(0xFF0E7490);
        btnCopyDistribution.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                android.content.ClipboardManager clipboard =
                        (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                StringBuilder text = new StringBuilder();
                List<Operation> operations = dbHelper.getOperations(selectedDate, null, "ALL");
                Map<String, int[]> distributions = new LinkedHashMap<String, int[]>();
                for (Operation op : operations) {
                    String name = op.getShopName();
                    if (name == null || name.trim().isEmpty() || op.getTotalCards() <= 0) continue;
                    if (!distributions.containsKey(name)) distributions.put(name, new int[]{0,0,0,0});
                    int[] counts = distributions.get(name);
                    counts[0] += op.getCard100(); counts[1] += op.getCard200();
                    counts[2] += op.getCard250(); counts[3] += op.getCard500();
                }
                for (Map.Entry<String, int[]> entry : distributions.entrySet()) {
                    int[] c = entry.getValue();
                    text.append(entry.getKey()).append("\\n")
                        .append(c[0]).append("-").append(c[1]).append("-")
                        .append(c[2]).append("-").append(c[3]).append("\\n\\n");
                }
                if (text.length() == 0) text.append("لا توجد عمليات توزيع لهذا التاريخ");
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("تفاصيل التوزيع", text.toString().trim()));
                Toast.makeText(ReportActivity.this, "تم نسخ جميع تفاصيل التوزيع", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(btnCopyDistribution);

        // Section: Distribution (Name on line 1, sequence on line 2)
        TextView tvDistTitle = new TextView(this);
        tvDistTitle.setText("📦 تفاصيل توزيع الكروت لكل محل");
        tvDistTitle.setTextSize(17);
        tvDistTitle.setTextColor(Color.WHITE);
        tvDistTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvDistTitle.setPadding(0, 16, 0, 6);
        root.addView(tvDistTitle);

        TextView tvExplanation = new TextView(this);
        tvExplanation.setText("ترتيب الأعداد: 100 - 200 - 250 - 500 ريال\nمثال: المشهد\n100-20-20-10");
        tvExplanation.setTextColor(0xFFFBBF24);
        tvExplanation.setTextSize(13);
        tvExplanation.setBackgroundColor(0xFF1E293B);
        tvExplanation.setPadding(12, 10, 12, 10);
        root.addView(tvExplanation);

        containerDistribution = new LinearLayout(this);
        containerDistribution.setOrientation(LinearLayout.VERTICAL);
        containerDistribution.setPadding(0, 10, 0, 20);
        root.addView(containerDistribution);

        // Section: Collection (Independent table)
        TextView tvColTitle = new TextView(this);
        tvColTitle.setText("💰 تفاصيل التحصيل والمبالغ المستلمة");
        tvColTitle.setTextSize(17);
        tvColTitle.setTextColor(Color.WHITE);
        tvColTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvColTitle.setPadding(0, 16, 0, 6);
        root.addView(tvColTitle);

        containerCollection = new LinearLayout(this);
        containerCollection.setOrientation(LinearLayout.VERTICAL);
        containerCollection.setPadding(0, 10, 0, 20);
        root.addView(containerCollection);

        // Totals Card
        LinearLayout totalsCard = new LinearLayout(this);
        totalsCard.setOrientation(LinearLayout.VERTICAL);
        totalsCard.setBackgroundColor(0xFF1E293B);
        totalsCard.setPadding(16, 16, 16, 16);

        TextView tvTotHeader = new TextView(this);
        tvTotHeader.setText("إجماليات اليوم الرسمية:");
        tvTotHeader.setTextColor(0xFF38BDF8);
        tvTotHeader.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTotHeader.setTextSize(15);
        totalsCard.addView(tvTotHeader);

        tvTotal100 = createSummaryRow(totalsCard, "فئة 100 ريال:", 0xFFEF4444);
        tvTotal200 = createSummaryRow(totalsCard, "فئة 200 ريال:", 0xFF8B5CF6);
        tvTotal250 = createSummaryRow(totalsCard, "فئة 250 ريال:", 0xFF10B981);
        tvTotal500 = createSummaryRow(totalsCard, "فئة 500 ريال:", 0xFFF59E0B);
        tvGrandCards = createSummaryRow(totalsCard, "إجمالي عدد الكروت الموزعة:", 0xFF38BDF8);
        tvGrandAmount = createSummaryRow(totalsCard, "إجمالي مبالغ التحصيل الفعلية:", 0xFF34D399);
        tvVisitedShops = createSummaryRow(totalsCard, "عدد المحلات المختلفة التي تمت زيارتها:", 0xFFA78BFA);

        root.addView(totalsCard);
        setContentView(scrollView);

        buildReport();
    }

    private TextView createSummaryRow(LinearLayout parent, String label, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 4, 0, 4);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextColor(0xFF94A3B8);
        tvLabel.setTextSize(14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        tvLabel.setLayoutParams(lp);
        row.addView(tvLabel);

        TextView tvVal = new TextView(this);
        tvVal.setTextColor(color);
        tvVal.setTextSize(15);
        tvVal.setTypeface(null, android.graphics.Typeface.BOLD);
        row.addView(tvVal);

        parent.addView(row);
        return tvVal;
    }

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                selectedDate = String.format(java.util.Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                tvReportDate.setText("تقرير تاريخ: " + selectedDate);
                buildReport();
            }
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void buildReport() {
        containerDistribution.removeAllViews();
        containerCollection.removeAllViews();

        List<Operation> ops = dbHelper.getOperations(selectedDate, null, "ALL");
        DailySummary summary = dbHelper.getDailySummary(selectedDate);

        // Group distributions by shop (summing if multiple distributions in same day)
        Map<String, int[]> shopDistMap = new LinkedHashMap<String, int[]>();
        // Group collections by shop
        Map<String, Double> shopColMap = new LinkedHashMap<String, Double>();

        for (Operation op : ops) {
            String shop = op.getShopName();
            if (shop == null || shop.trim().isEmpty()) continue;

            if (op.getTotalCards() > 0) {
                if (!shopDistMap.containsKey(shop)) {
                    shopDistMap.put(shop, new int[]{0, 0, 0, 0});
                }
                int[] arr = shopDistMap.get(shop);
                arr[0] += op.getCard100();
                arr[1] += op.getCard200();
                arr[2] += op.getCard250();
                arr[3] += op.getCard500();
            }

            if (op.getCollectedAmount() > 0) {
                double current = shopColMap.containsKey(shop) ? shopColMap.get(shop) : 0.0;
                shopColMap.put(shop, current + op.getCollectedAmount());
            }
        }

        // Render Distribution Section (Name on Line 1, Sequence on Line 2)
        if (shopDistMap.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("لا توجد عمليات توزيع مسجلة لهذا التاريخ");
            empty.setTextColor(0xFF64748B);
            empty.setPadding(10, 10, 10, 10);
            containerDistribution.addView(empty);
        } else {
            for (Map.Entry<String, int[]> entry : shopDistMap.entrySet()) {
                String shopName = entry.getKey();
                int[] counts = entry.getValue();
                String seq = counts[0] + "-" + counts[1] + "-" + counts[2] + "-" + counts[3];
                int totalForShop = counts[0] + counts[1] + counts[2] + counts[3];

                LinearLayout block = new LinearLayout(this);
                block.setOrientation(LinearLayout.VERTICAL);
                block.setBackgroundColor(0xFF1E293B);
                block.setPadding(16, 12, 16, 12);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 0, 0, 8);
                block.setLayoutParams(lp);

                // Line 1: Shop Name
                TextView tvName = new TextView(this);
                tvName.setText(shopName);
                tvName.setTextColor(Color.WHITE);
                tvName.setTextSize(16);
                tvName.setTypeface(null, android.graphics.Typeface.BOLD);
                block.addView(tvName);

                // Line 2: Sequence of numbers (100-20-20-10)
                TextView tvSeq = new TextView(this);
                tvSeq.setText(seq);
                tvSeq.setTextColor(0xFF38BDF8); // sky-400
                tvSeq.setTextSize(18);
                tvSeq.setTypeface(null, android.graphics.Typeface.BOLD);
                tvSeq.setPadding(0, 4, 0, 2);
                block.addView(tvSeq);

                // Optional total for shop on separate line
                TextView tvShopTot = new TextView(this);
                tvShopTot.setText("إجمالي الكروت: " + totalForShop);
                tvShopTot.setTextColor(0xFF94A3B8);
                tvShopTot.setTextSize(12);
                block.addView(tvShopTot);

                containerDistribution.addView(block);
            }
        }

        // Render Collection Section
        if (shopColMap.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("لا توجد مبالغ تحصيل مسجلة لهذا التاريخ");
            empty.setTextColor(0xFF64748B);
            empty.setPadding(10, 10, 10, 10);
            containerCollection.addView(empty);
        } else {
            for (Map.Entry<String, Double> entry : shopColMap.entrySet()) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setBackgroundColor(0xFF1E293B);
                row.setPadding(16, 12, 16, 12);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 0, 0, 8);
                row.setLayoutParams(lp);

                TextView tvName = new TextView(this);
                tvName.setText(entry.getKey());
                tvName.setTextColor(Color.WHITE);
                tvName.setTextSize(15);
                LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
                tvName.setLayoutParams(np);
                row.addView(tvName);

                TextView tvAmt = new TextView(this);
                tvAmt.setText(String.format(java.util.Locale.US, "%,.0f", entry.getValue()) + " ريال");
                tvAmt.setTextColor(0xFF34D399);
                tvAmt.setTextSize(16);
                tvAmt.setTypeface(null, android.graphics.Typeface.BOLD);
                row.addView(tvAmt);

                containerCollection.addView(row);
            }
        }

        // Update Totals
        tvTotal100.setText(String.valueOf(summary.totalCard100));
        tvTotal200.setText(String.valueOf(summary.totalCard200));
        tvTotal250.setText(String.valueOf(summary.totalCard250));
        tvTotal500.setText(String.valueOf(summary.totalCard500));
        tvGrandCards.setText(String.valueOf(summary.getTotalCards()));
        tvGrandAmount.setText(String.format(java.util.Locale.US, "%,.0f", summary.totalCollected) + " ريال");
        tvVisitedShops.setText(String.valueOf(summary.visitedShopsCount));
    }

    private String generateReportText() {
        StringBuilder sb = new StringBuilder();
        sb.append("═══════════════════════════════\n");
        sb.append("   الكامل للتوزيع والتحصيل   \n");
        sb.append("═══════════════════════════════\n");
        sb.append("تاريخ الفاتورة: ").append(selectedDate).append("\n\n");

        sb.append("📦 تفاصيل توزيع الكروت:\n");
        sb.append("ترتيب الأعداد: 100 - 200 - 250 - 500 ريال\n");
        sb.append("───────────────────────────────\n");

        List<Operation> ops = dbHelper.getOperations(selectedDate, null, "ALL");
        Map<String, int[]> shopDistMap = new LinkedHashMap<String, int[]>();
        Map<String, Double> shopColMap = new LinkedHashMap<String, Double>();

        for (Operation op : ops) {
            String shop = op.getShopName();
            if (shop == null || shop.trim().isEmpty()) continue;
            if (op.getTotalCards() > 0) {
                if (!shopDistMap.containsKey(shop)) shopDistMap.put(shop, new int[]{0,0,0,0});
                int[] a = shopDistMap.get(shop);
                a[0] += op.getCard100(); a[1] += op.getCard200(); a[2] += op.getCard250(); a[3] += op.getCard500();
            }
            if (op.getCollectedAmount() > 0) {
                double c = shopColMap.containsKey(shop) ? shopColMap.get(shop) : 0.0;
                shopColMap.put(shop, c + op.getCollectedAmount());
            }
        }

        for (Map.Entry<String, int[]> e : shopDistMap.entrySet()) {
            sb.append(e.getKey()).append("\n");
            int[] c = e.getValue();
            sb.append(c[0]).append("-").append(c[1]).append("-").append(c[2]).append("-").append(c[3]).append("\n\n");
        }

        sb.append("💰 تفاصيل التحصيل:\n");
        sb.append("───────────────────────────────\n");
        for (Map.Entry<String, Double> e : shopColMap.entrySet()) {
            sb.append(e.getKey()).append(": ").append(String.format(java.util.Locale.US, "%,.0f", e.getValue())).append(" ريال\n");
        }

        DailySummary s = dbHelper.getDailySummary(selectedDate);
        sb.append("\n═══════════════════════════════\n");
        sb.append("إجمالي كروت 100: ").append(s.totalCard100).append("\n");
        sb.append("إجمالي كروت 200: ").append(s.totalCard200).append("\n");
        sb.append("إجمالي كروت 250: ").append(s.totalCard250).append("\n");
        sb.append("إجمالي كروت 500: ").append(s.totalCard500).append("\n");
        sb.append("إجمالي عدد الكروت: ").append(s.getTotalCards()).append("\n");
        sb.append("إجمالي المبالغ المحصلة: ").append(String.format(java.util.Locale.US, "%,.0f", s.totalCollected)).append(" ريال\n");
        sb.append("عدد المحلات المزورة: ").append(s.visitedShopsCount).append("\n");
        sb.append("═══════════════════════════════\n");

        return sb.toString();
    }

    private void shareReportText() {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, generateReportText());
        sendIntent.setType("text/plain");
        startActivity(Intent.createChooser(sendIntent, "مشاركة تقرير اليوم"));
    }



    /** Creates one PDF: page one for collections, page two for distribution. */
    private void exportDistributionPdf() {
        if (Build.VERSION.SDK_INT < 19) {
            Toast.makeText(this, "إنشاء PDF يحتاج Android 4.4 أو أحدث", Toast.LENGTH_LONG).show();
            return;
        }
        PdfDocument pdf = new PdfDocument();
        try {
            final int w=595, h=842, left=42, cw=w-84;
            TextPaint title=new TextPaint(); title.setColor(Color.rgb(15,45,75)); title.setTextSize(21); title.setFakeBoldText(true);
            TextPaint normal=new TextPaint(); normal.setColor(Color.rgb(30,41,59)); normal.setTextSize(14);
            TextPaint total=new TextPaint(); total.setColor(Color.rgb(5,120,75)); total.setTextSize(16); total.setFakeBoldText(true);
            TextPaint muted=new TextPaint(); muted.setColor(Color.rgb(71,85,105)); muted.setTextSize(12);
            TextPaint white=new TextPaint(title); white.setColor(Color.WHITE);
            TextPaint sub=new TextPaint(); sub.setColor(Color.rgb(220,235,248)); sub.setTextSize(13);
            List<Operation> ops=dbHelper.getOperations(selectedDate,null,"ALL");
            Map<String,int[]> dist=new LinkedHashMap<String,int[]>();
            Map<String,Double> col=new LinkedHashMap<String,Double>();
            for(Operation op:ops){
                String name=op.getShopName(); if(name==null||name.trim().isEmpty()) continue;
                if(op.getTotalCards()>0){
                    if(!dist.containsKey(name)) dist.put(name,new int[]{0,0,0,0});
                    int[] c=dist.get(name); c[0]+=op.getCard100(); c[1]+=op.getCard200(); c[2]+=op.getCard250(); c[3]+=op.getCard500();
                }
                if(op.getCollectedAmount()>0){
                    Double old=col.containsKey(name)?col.get(name):0.0;
                    col.put(name,old+op.getCollectedAmount());
                }
            }
            android.graphics.Paint banner=new android.graphics.Paint(3); banner.setColor(Color.rgb(15,45,75));
            android.graphics.Paint line=new android.graphics.Paint(3); line.setColor(Color.rgb(226,232,240));
            // Page 1: collection only
            PdfDocument.Page p1=pdf.startPage(new PdfDocument.PageInfo.Builder(w,h,1).create());
            android.graphics.Canvas c1=p1.getCanvas(); c1.drawColor(Color.WHITE); c1.drawRoundRect(left-8,22,w-left+8,105,12,12,banner);
            int y=48; y=drawPdfText(c1,"الكامل للتوزيع والتحصيل",left,y,cw,white);
            y=drawPdfText(c1,"الصفحة الأولى: تقرير التحصيل",left,y,cw,sub); y+=8;
            y=drawPdfText(c1,"تاريخ التقرير: "+selectedDate,left,y,cw,normal); y+=10;
            c1.drawLine(left,y,w-left,y,line); y+=16;
            double colTotal=0;
            if(col.isEmpty()) y=drawPdfText(c1,"لا توجد عمليات تحصيل مسجلة لهذا التاريخ",left,y,cw,normal);
            else for(Map.Entry<String,Double> e:col.entrySet()){
                y=drawPdfText(c1,e.getKey(),left,y,cw,title);
                y=drawPdfText(c1,String.format(java.util.Locale.US,"%,.0f",e.getValue())+" ريال",left,y,cw,total);
                y+=8; colTotal+=e.getValue();
            }
            y+=12; drawPdfText(c1,"إجمالي التحصيل الفعلي: "+String.format(java.util.Locale.US,"%,.0f",colTotal)+" ريال",left,y,cw,total);
            pdf.finishPage(p1);
            // Page 2: distribution only
            PdfDocument.Page p2=pdf.startPage(new PdfDocument.PageInfo.Builder(w,h,2).create());
            android.graphics.Canvas c2=p2.getCanvas(); c2.drawColor(Color.WHITE); c2.drawRoundRect(left-8,22,w-left+8,105,12,12,banner);
            y=48; y=drawPdfText(c2,"الكامل للتوزيع والتحصيل",left,y,cw,white);
            y=drawPdfText(c2,"الصفحة الثانية: تقرير توزيع الكروت",left,y,cw,sub); y+=8;
            y=drawPdfText(c2,"تاريخ التقرير: "+selectedDate,left,y,cw,normal);
            y=drawPdfText(c2,"ترتيب الأعداد: 100 - 200 - 250 - 500 ريال",left,y,cw,muted); y+=10;
            c2.drawLine(left,y,w-left,y,line); y+=16;
            long n100=0,n200=0,n250=0,n500=0,distTotal=0;
            if(dist.isEmpty()) y=drawPdfText(c2,"لا توجد عمليات توزيع مسجلة لهذا التاريخ",left,y,cw,normal);
            else for(Map.Entry<String,int[]> e:dist.entrySet()){
                int[] a=e.getValue(); long amount=a[0]*85L+a[1]*180L+a[2]*225L+a[3]*450L;
                n100+=a[0]; n200+=a[1]; n250+=a[2]; n500+=a[3]; distTotal+=amount;
                y=drawPdfText(c2,e.getKey(),left,y,cw,title);
                y=drawPdfText(c2,a[0]+"-"+a[1]+"-"+a[2]+"-"+a[3],left,y,cw,normal);
                y=drawPdfText(c2,"إجمالي قيمة التوزيع: "+String.format(java.util.Locale.US,"%,d",amount)+" ريال",left,y,cw,total); y+=9;
            }
            y+=8; line.setColor(Color.rgb(119,201,245)); line.setStrokeWidth(2); c2.drawLine(left,y,w-left,y,line); y+=12;
            y=drawPdfText(c2,"إجمالي فئة 100: "+n100,left,y,cw,normal);
            y=drawPdfText(c2,"إجمالي فئة 200: "+n200,left,y,cw,normal);
            y=drawPdfText(c2,"إجمالي فئة 250: "+n250,left,y,cw,normal);
            y=drawPdfText(c2,"إجمالي فئة 500: "+n500,left,y,cw,normal);
            drawPdfText(c2,"إجمالي قيمة التوزيع: "+String.format(java.util.Locale.US,"%,d",distTotal)+" ريال",left,y,cw,total);
            pdf.finishPage(p2);
            ByteArrayOutputStream out=new ByteArrayOutputStream(); pdf.writeTo(out); pendingDistributionPdf=out.toByteArray();
            Intent create=new Intent(Intent.ACTION_CREATE_DOCUMENT); create.addCategory(Intent.CATEGORY_OPENABLE); create.setType("application/pdf");
            create.putExtra(Intent.EXTRA_TITLE,"فاتورة_اليوم_التحصيل_والتوزيع_"+selectedDate+".pdf"); startActivityForResult(create,7301);
        }catch(Exception e){Toast.makeText(this,"تعذر إنشاء فاتورة PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        finally{pdf.close();}
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 7301) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingDistributionPdf != null) {
                OutputStream output = null;
                try {
                    output = getContentResolver().openOutputStream(data.getData(), "w");
                    if (output == null) throw new java.io.IOException("تعذر فتح ملف الحفظ");
                    output.write(pendingDistributionPdf);
                    output.flush();
                    Toast.makeText(this, "تم حفظ فاتورة التوزيع PDF بنجاح", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "تعذر حفظ PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                } finally {
                    try { if (output != null) output.close(); } catch (Exception ignored) {}
                    pendingDistributionPdf = null;
                }
            } else {
                pendingDistributionPdf = null;
                Toast.makeText(this, "تم إلغاء حفظ الفاتورة", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private int drawPdfText(android.graphics.Canvas canvas, String text, int x, int y, int width, TextPaint paint) {
        StaticLayout layout = new StaticLayout(text, paint, width, Layout.Alignment.ALIGN_OPPOSITE, 1.15f, 0f, false);
        canvas.save();
        canvas.translate(x, y);
        layout.draw(canvas);
        canvas.restore();
        return y + layout.getHeight() + 3;
    }

    private void exportReportFile() {
        try {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists()) dir.mkdirs();
            String fileName = "تقرير_التوزيع_والتحصيل_" + selectedDate + ".txt";
            File file = new File(dir, fileName);

            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            osw.write(generateReportText());
            osw.close();
            fos.close();

            Toast.makeText(this, "تم حفظ الملف بنجاح في مجلد التنزيلات:\n" + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "خطأ أثناء الحفظ: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
