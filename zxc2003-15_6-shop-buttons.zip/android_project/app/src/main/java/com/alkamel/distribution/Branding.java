package com.alkamel.distribution;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared visual identity and contact footer for all screens. */
public final class Branding {
    private Branding() {}

    public static GradientDrawable background() {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF071B49, 0xFF123C83, 0xFF07152F});
        d.setCornerRadius(0f);
        return d;
    }

    public static GradientDrawable rounded(int color, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(18f);
        d.setStroke(2, strokeColor);
        return d;
    }

    public static void styleButton(Button button, int color) {
        button.setBackground(rounded(color, 0x667DD3FC));
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setPadding(16, 14, 16, 14);
        if (button.getMinimumHeight() < 52) button.setMinHeight(52);
    }

    public static void styleInput(EditText input) {
        input.setBackground(rounded(0xFF102B58, 0xFF3B82B8));
        input.setPadding(16, 14, 16, 14);
        input.setTextColor(0xFFF8FAFC);
        input.setHintTextColor(0xFFB6C8E4);
    }

    public static void addFooter(final Activity activity, LinearLayout parent) {
        LinearLayout footer = new LinearLayout(activity);
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(12, 22, 12, 12);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fp.setMargins(0, 24, 0, 0);
        footer.setLayoutParams(fp);
        footer.setBackground(rounded(0xAA07152F, 0x664EA5E9));

        TextView credit = new TextView(activity);
        credit.setText("تصميم محمد كامل العجاج | 772072056");
        credit.setTextColor(0xFFE0ECFF);
        credit.setTextSize(14);
        credit.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        credit.setGravity(Gravity.CENTER);
        footer.addView(credit);

        TextView contact = new TextView(activity);
        contact.setText("واتساب للتواصل: 772072056  ◉ اضغط هنا");
        contact.setTextColor(0xFF86EFAC);
        contact.setTextSize(15);
        contact.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        contact.setGravity(Gravity.CENTER);
        contact.setPadding(8, 12, 8, 8);
        contact.setClickable(true);
        contact.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://wa.me/967772072056?text=" + Uri.encode("السلام عليكم، أريد التواصل بخصوص تطبيق الكامل للتوزيع والتحصيل")));
                    activity.startActivity(i);
                } catch (Exception ignored) {
                    android.widget.Toast.makeText(activity, "تعذر فتح واتساب أو المتصفح", android.widget.Toast.LENGTH_LONG).show();
                }
            }
        });
        footer.addView(contact);
        parent.addView(footer);
    }
}
