package com.alkamel.distribution.model;

public class DailySummary {
    public int totalCard100 = 0;
    public int totalCard200 = 0;
    public int totalCard250 = 0;
    public int totalCard500 = 0;
    public double totalCollected = 0.0;
    public int visitedShopsCount = 0;

    public int getTotalCards() {
        return totalCard100 + totalCard200 + totalCard250 + totalCard500;
    }
}
