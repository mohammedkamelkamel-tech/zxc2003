package com.alkamel.distribution.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateUtils {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm:ss", Locale.US);
    private static final SimpleDateFormat DISPLAY_DATE_FORMAT = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault());

    public static String getTodayDate() {
        return DATE_FORMAT.format(new Date());
    }

    public static String getCurrentTime() {
        return TIME_FORMAT.format(new Date());
    }

    public static String formatDisplayDate(String dateStr) {
        try {
            Date d = DATE_FORMAT.parse(dateStr);
            return DISPLAY_DATE_FORMAT.format(d);
        } catch (Exception e) {
            return dateStr;
        }
    }
}
