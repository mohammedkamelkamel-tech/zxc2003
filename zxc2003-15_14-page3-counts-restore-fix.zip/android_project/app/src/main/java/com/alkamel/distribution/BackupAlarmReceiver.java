package com.alkamel.distribution;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BackupAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        BackupActivity.createScheduledBackup(context.getApplicationContext());
        BackupScheduler.scheduleDaily(context.getApplicationContext());
    }
}
