package com.alkamel.distribution;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.alkamel.distribution.database.DatabaseHelper;
import com.alkamel.distribution.util.DateUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BackupActivity extends Activity {
    private DatabaseHelper dbHelper;
    private TextView tvStatus;
    private static final int REQUEST_BACKUP_FOLDER = 7104;
    private static final int REQUEST_RESTORE_FILE = 7105;
    private static final String PREFS = "alkamel_backup_settings";
    private static final String KEY_FOLDER_URI = "backup_folder_uri";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = DatabaseHelper.getInstance(this);
        setTitle("النسخ الاحتياطي واستعادة البيانات");
        initUI();
        BackupScheduler.scheduleDaily(this);
    }

    private void initUI() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scrollView.setBackground(Branding.background());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Branding.background());
        root.setPadding(24, 24, 24, 40);
        scrollView.addView(root);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("💾 النسخ الاحتياطي والاستعادة المحلية");
        tvTitle.setTextSize(20);
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(tvTitle);

        TextView tvDesc = new TextView(this);
        tvDesc.setText("يعمل النسخ الاحتياطي محلياً وبدون إنترنت لحماية كافة بيانات المحلات والعمليات.");
        tvDesc.setTextColor(0xFF94A3B8);
        tvDesc.setTextSize(13);
        tvDesc.setPadding(0, 8, 0, 24);
        root.addView(tvDesc);

        Button btnChooseFolder = new Button(this);
        btnChooseFolder.setText("📁 تحديد مجلد النسخ الاحتياطي التلقائي");
        btnChooseFolder.setTextSize(16);
        btnChooseFolder.setTextColor(Color.WHITE);
        btnChooseFolder.setBackgroundColor(0xFF334155);
        Branding.styleButton(btnChooseFolder, 0xFF334155);
        btnChooseFolder.setPadding(20, 20, 20, 20);
        btnChooseFolder.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { chooseBackupFolder(); }
        });
        root.addView(btnChooseFolder);

        TextView tvAuto = new TextView(this);
        tvAuto.setText("النسخ الاحتياطي التلقائي: يوميًا الساعة 1:00 صباحًا في المجلد المحدد. اختر المجلد مرة واحدة واترك التطبيق يحتفظ بالنسخ اليومية تلقائيًا.");
        tvAuto.setTextColor(0xFFCBD5E1);
        tvAuto.setTextSize(13);
        tvAuto.setPadding(0, 8, 0, 16);
        root.addView(tvAuto);

        // Backup Section
        Button btnBackup = new Button(this);
        btnBackup.setText("📤 إنشاء نسخة احتياطية جديدة الآن");
        btnBackup.setTextSize(16);
        btnBackup.setTextColor(Color.WHITE);
        btnBackup.setBackgroundColor(0xFF059669);
        Branding.styleButton(btnBackup, 0xFF059669);
        btnBackup.setPadding(20, 20, 20, 20);
        btnBackup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createBackup();
            }
        });
        root.addView(btnBackup);

        TextView tvDailyBackup = new TextView(this);
        tvDailyBackup.setText("⏰ النسخ التلقائي اليومي مجدول الساعة 1:00 صباحًا بجوار النسخة اليدوية أعلاه.");
        tvDailyBackup.setTextSize(14);
        tvDailyBackup.setTextColor(0xFF86EFAC);
        tvDailyBackup.setPadding(4, 10, 4, 12);
        root.addView(tvDailyBackup);
        BackupScheduler.scheduleDaily(this);

        // Restore Section
        Button btnRestore = new Button(this);
        btnRestore.setText("📥 استعادة البيانات من نسخة سابقة");
        btnRestore.setTextSize(16);
        btnRestore.setTextColor(Color.WHITE);
        btnRestore.setBackgroundColor(0xFF2563EB);
        Branding.styleButton(btnRestore, 0xFF2563EB);
        btnRestore.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.setMargins(0, 16, 0, 24);
        btnRestore.setLayoutParams(rp);
        btnRestore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseRestoreFile();
            }
        });
        root.addView(btnRestore);

        tvStatus = new TextView(this);
        tvStatus.setTextColor(0xFF38BDF8);
        tvStatus.setTextSize(13);
        tvStatus.setPadding(0, 10, 0, 10);
        root.addView(tvStatus);

        Branding.addFooter(this, root);
        setContentView(scrollView);
    }

    private void chooseBackupFolder() {
        if (Build.VERSION.SDK_INT < 21) {
            Toast.makeText(this, "اختيار مجلد تلقائي يحتاج Android 5 أو أحدث. سيتم استخدام مجلد التنزيلات على هذا الجهاز.", Toast.LENGTH_LONG).show();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("use_downloads_fallback", true).apply();
            BackupScheduler.scheduleDaily(this);
            createBackup();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_BACKUP_FOLDER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQUEST_RESTORE_FILE) {
            confirmRestoreFromUri(uri);
            return;
        }
        if (requestCode != REQUEST_BACKUP_FOLDER) return;
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_FOLDER_URI, uri.toString()).putBoolean("use_downloads_fallback", false).apply();
            BackupScheduler.scheduleDaily(this);
            tvStatus.setText("تم حفظ مسار النسخ الاحتياطي. جارٍ إنشاء نسخة تلقائية...");
            createBackup();
        } catch (Exception e) {
            tvStatus.setText("تعذر حفظ صلاحية المجلد: " + e.getMessage());
            Toast.makeText(this, "تعذر حفظ المسار المحدد", Toast.LENGTH_LONG).show();
        }
    }

    private Uri getSavedFolderUri() {
        String value = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_FOLDER_URI, null);
        if (value == null || value.trim().isEmpty()) return null;
        try { return Uri.parse(value); } catch (Exception e) { return null; }
    }

    private String makeBackupFileName() {
        String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date());
        return "alkamel_backup_" + stamp + ".json";
    }

    private void createBackup() {
        try {
            String json = dbHelper.exportBackupJSON();
            String fileName = makeBackupFileName();
            Uri folderUri = getSavedFolderUri();
            if (folderUri != null && Build.VERSION.SDK_INT >= 21) {
                Uri fileUri = createDocumentInFolder(folderUri, fileName);
                OutputStream out = getContentResolver().openOutputStream(fileUri, "w");
                if (out == null) throw new java.io.IOException("تعذر فتح ملف النسخة للكتابة");
                OutputStreamWriter writer = new OutputStreamWriter(out, "UTF-8");
                writer.write(json);
                writer.flush();
                writer.close();
                tvStatus.setText("تم النسخ الاحتياطي تلقائيًا بنجاح داخل المجلد المحدد:\n" + fileName);
                Toast.makeText(this, "تم حفظ النسخة الاحتياطية تلقائيًا", Toast.LENGTH_LONG).show();
                return;
            }
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists() && !dir.mkdirs() && !dir.exists()) throw new java.io.IOException("تعذر إنشاء مجلد التنزيلات");
            File backupFile = new File(dir, fileName);
            FileOutputStream fos = new FileOutputStream(backupFile);
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            osw.write(json);
            osw.close();
            fos.close();
            tvStatus.setText("تم إنشاء النسخة الاحتياطية بنجاح:\n" + backupFile.getAbsolutePath());
            Toast.makeText(this, "تم إنشاء النسخة الاحتياطية بنجاح!", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            tvStatus.setText("فشل النسخ الاحتياطي: " + e.getMessage());
            Toast.makeText(this, "فشل النسخ الاحتياطي: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private Uri createDocumentInFolder(Uri treeUri, String fileName) throws Exception {
        Uri treeDocument = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri));
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri));
        Cursor cursor = getContentResolver().query(childrenUri, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    String existingName = cursor.getString(1);
                    if (fileName.equals(existingName)) {
                        String id = cursor.getString(0);
                        return DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                    }
                }
            } finally { cursor.close(); }
        }
        return DocumentsContract.createDocument(getContentResolver(), treeDocument, "application/json", fileName);
    }


    public static void autoBackupIfConfigured(android.content.Context context) {
        // Kept as a compatibility entry point; automatic backups are now scheduled daily at 01:00.
        BackupScheduler.scheduleDaily(context);
    }

    public static void createScheduledBackup(android.content.Context context) {
        java.io.OutputStream out = null;
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS, MODE_PRIVATE);
            String folder = prefs.getString(KEY_FOLDER_URI, null);
            String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date());
            String fileName = "alkamel_backup_" + stamp + ".json";
            String json = DatabaseHelper.getInstance(context).exportBackupJSON();
            if (folder != null && !folder.trim().isEmpty() && Build.VERSION.SDK_INT >= 21) {
                Uri treeUri = Uri.parse(folder);
                Uri treeDocument = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri));
                Uri fileUri = DocumentsContract.createDocument(context.getContentResolver(), treeDocument, "application/json", fileName);
                if (fileUri == null) throw new java.io.IOException("تعذر إنشاء ملف النسخة داخل المجلد المحدد");
                out = context.getContentResolver().openOutputStream(fileUri, "w");
                if (out == null) throw new java.io.IOException("تعذر فتح ملف النسخة للكتابة");
                OutputStreamWriter writer = new OutputStreamWriter(out, "UTF-8");
                writer.write(json);
                writer.flush();
                writer.close();
                out = null;
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs() && !dir.exists()) throw new java.io.IOException("تعذر إنشاء مجلد التنزيلات");
                File file = new File(dir, fileName);
                FileOutputStream fos = new FileOutputStream(file);
                OutputStreamWriter writer = new OutputStreamWriter(fos, "UTF-8");
                writer.write(json);
                writer.close();
                fos.close();
            }
            prefs.edit().putString("last_auto_backup", stamp).putString("last_auto_backup_status", "success").apply();
        } catch (Exception e) {
            context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("last_auto_backup_status", "failed: " + e.getMessage()).apply();
        } finally {
            try { if (out != null) out.close(); } catch (Exception ignored) { }
        }
    }

    /** Opens Android's file picker so the user can browse to and tap a backup file. */
    private void chooseRestoreFile() {
        Intent intent;
        if (Build.VERSION.SDK_INT >= 19) {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            // Do not restrict MIME: some Android 7 file providers label JSON as octet-stream.
            // The selected content is validated as JSON before import.
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        } else {
            // ACTION_OPEN_DOCUMENT is unavailable on Android 4.0–4.3.
            intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        try {
            startActivityForResult(Intent.createChooser(intent, "اختر ملف النسخة الاحتياطية"), REQUEST_RESTORE_FILE);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح مدير الملفات على هذا الجهاز", Toast.LENGTH_LONG).show();
        }
    }

    private void confirmRestoreFromUri(final Uri uri) {
        String name = getDisplayName(uri);
        new AlertDialog.Builder(this)
                .setTitle("تأكيد استعادة النسخة")
                .setMessage("الملف المحدد: " + name + "\n\nستستبدل الاستعادة البيانات الحالية ببيانات النسخة الاحتياطية. هل تريد المتابعة؟")
                .setPositiveButton("استعادة الآن", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        restoreFromUri(uri);
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private String getDisplayName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[]{"_display_name"}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) return cursor.getString(0);
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "ملف النسخة الاحتياطية" : last;
    }

    private void restoreFromUri(Uri uri) {
        try {
            java.io.InputStream input = getContentResolver().openInputStream(uri);
            if (input == null) throw new java.io.IOException("تعذر فتح ملف النسخة المحدد");
            BufferedReader br = new BufferedReader(new InputStreamReader(input, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            br.close();

            boolean success = dbHelper.importBackupJSON(sb.toString());
            if (success) {
                tvStatus.setText("تمت استعادة البيانات بنجاح من الملف: " + getDisplayName(uri));
                Toast.makeText(this, "تمت الاستعادة بنجاح!", Toast.LENGTH_LONG).show();
            } else {
                tvStatus.setText("فشلت الاستعادة: صيغة الملف غير صحيحة أو تالفة.");
                Toast.makeText(this, "ملف النسخة الاحتياطية غير صالح أو تالف", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            tvStatus.setText("خطأ أثناء قراءة النسخة الاحتياطية: " + e.getMessage());
            Toast.makeText(this, "تعذر استعادة النسخة: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

}
