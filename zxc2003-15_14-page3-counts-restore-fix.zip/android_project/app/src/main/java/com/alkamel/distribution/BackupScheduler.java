package com.alkamel.distribution;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

/** Schedules a repeating local backup for 01:00 every day. */
public final class BackupScheduler {
    private static final int REQUEST_CODE = 8417;
    private BackupScheduler() { }

    public static void scheduleDaily(Context context) {
        try {
            AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarm == null) return;
            Intent intent = new Intent(context, BackupAlarmReceiver.class);
            PendingIntent pending;
            if (Build.VERSION.SDK_INT >= 23) {
                pending = PendingIntent.getBroadcast(context, REQUEST_CODE, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            } else {
                pending = PendingIntent.getBroadcast(context, REQUEST_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            }
            Calendar next = Calendar.getInstance();
            next.set(Calendar.HOUR_OF_DAY, 1);
            next.set(Calendar.MINUTE, 0);
            next.set(Calendar.SECOND, 0);
            next.set(Calendar.MILLISECOND, 0);
            if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_YEAR, 1);
            // Prefer an exact 01:00 alarm where Android permits it; fall back safely otherwise.
            try {
                if (Build.VERSION.SDK_INT >= 23) {
                    alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pending);
                } else if (Build.VERSION.SDK_INT >= 19) {
                    alarm.setExact(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pending);
                } else {
                    alarm.set(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pending);
                }
            } catch (SecurityException exactNotAllowed) {
                alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(),
                        AlarmManager.INTERVAL_DAY, pending);
            }
        } catch (Exception ignored) { }
    }
}
