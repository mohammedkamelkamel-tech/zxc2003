package com.alkamel.distribution;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.alkamel.distribution.database.DatabaseHelper;
import com.alkamel.distribution.model.DailySummary;
import com.alkamel.distribution.model.Operation;
import com.alkamel.distribution.util.DateUtils;

import java.util.Calendar;
import java.util.List;

public class HistoryActivity extends Activity {
    private DatabaseHelper dbHelper;
    private String selectedDate;
    private String currentTypeFilter = "ALL";
    private TextView tvDateDisplay;
    private EditText etSearchShop;
    private LinearLayout opsContainer;
    private TextView tvSummaryInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = DatabaseHelper.getInstance(this);
        selectedDate = DateUtils.getTodayDate();
        setTitle("سجل العمليات");
        initUI();
    }

    private void initUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Branding.background());
        root.setPadding(20, 20, 20, 20);

        // Date selection bar
        LinearLayout dateBar = new LinearLayout(this);
        dateBar.setOrientation(LinearLayout.HORIZONTAL);
        dateBar.setGravity(Gravity.CENTER_VERTICAL);
        dateBar.setBackgroundColor(0xFF1E293B);
        dateBar.setPadding(16, 12, 16, 12);

        tvDateDisplay = new TextView(this);
        tvDateDisplay.setText("التاريخ: " + selectedDate);
        tvDateDisplay.setTextColor(Color.WHITE);
        tvDateDisplay.setTextSize(16);
        tvDateDisplay.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        tvDateDisplay.setLayoutParams(dp);
        dateBar.addView(tvDateDisplay);

        Button btnChangeDate = new Button(this);
        btnChangeDate.setText("📅 تغيير التاريخ");
        btnChangeDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });
        dateBar.addView(btnChangeDate);
        root.addView(dateBar);

        // Filter Type buttons
        LinearLayout filterBar = new LinearLayout(this);
        filterBar.setOrientation(LinearLayout.HORIZONTAL);
        filterBar.setPadding(0, 10, 0, 10);
        filterBar.setWeightSum(4);

        createFilterButton(filterBar, "الكل", "ALL");
        createFilterButton(filterBar, "توزيع", "DISTRIBUTION");
        createFilterButton(filterBar, "تحصيل", "COLLECTION");
        createFilterButton(filterBar, "معاً", "BOTH");
        root.addView(filterBar);

        // Search Shop
        etSearchShop = new EditText(this);
        etSearchShop.setHint("🔍 بحث باسم المحل...");
        etSearchShop.setTextColor(Color.WHITE);
        etSearchShop.setBackgroundColor(0xFF1E293B);
        Branding.styleInput(etSearchShop);
        etSearchShop.setPadding(14, 14, 14, 14);
        etSearchShop.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                refreshOperations();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
        root.addView(etSearchShop);

        // Daily Summary header
        tvSummaryInfo = new TextView(this);
        tvSummaryInfo.setTextColor(0xFFFBBF24);
        tvSummaryInfo.setTextSize(13);
        tvSummaryInfo.setPadding(0, 10, 0, 10);
        root.addView(tvSummaryInfo);

        // Scrollable list
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        opsContainer = new LinearLayout(this);
        opsContainer.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(opsContainer);

        root.addView(scrollView);
        Branding.addFooter(this, root);
        setContentView(root);

        refreshOperations();
    }

    private void createFilterButton(LinearLayout parent, String title, final String type) {
        Button btn = new Button(this);
        btn.setText(title);
        btn.setTextSize(12);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        lp.setMargins(2, 0, 2, 0);
        btn.setLayoutParams(lp);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentTypeFilter = type;
                refreshOperations();
            }
        });
        parent.addView(btn);
    }

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                selectedDate = String.format(java.util.Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                tvDateDisplay.setText("التاريخ: " + selectedDate);
                refreshOperations();
            }
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void refreshOperations() {
        opsContainer.removeAllViews();
        String query = etSearchShop.getText().toString();
        List<Operation> list = dbHelper.getOperations(selectedDate, query, currentTypeFilter);
        DailySummary summary = dbHelper.getDailySummary(selectedDate);

        tvSummaryInfo.setText("إجمالي اليوم: " + summary.getTotalCards() + " كرت | " +
                String.format(java.util.Locale.US, "%,.0f", summary.totalCollected) + " ريال | " +
                summary.visitedShopsCount + " محل");

        if (list.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("لا توجد عمليات مسجلة لهذا التاريخ");
            empty.setTextColor(0xFF94A3B8);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(20, 40, 20, 20);
            opsContainer.addView(empty);
            return;
        }

        for (final Operation op : list) {
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setBackgroundColor(0xFF1E293B);
            item.setPadding(16, 16, 16, 16);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 10);
            item.setLayoutParams(lp);

            LinearLayout topRow = new LinearLayout(this);
            topRow.setOrientation(LinearLayout.HORIZONTAL);

            TextView tvShop = new TextView(this);
            tvShop.setText(op.getShopName());
            tvShop.setTextSize(16);
            tvShop.setTextColor(Color.WHITE);
            tvShop.setTypeface(null, android.graphics.Typeface.BOLD);
            LinearLayout.LayoutParams spP = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
            tvShop.setLayoutParams(spP);
            topRow.addView(tvShop);

            TextView tvTime = new TextView(this);
            tvTime.setText(op.getTime());
            tvTime.setTextColor(0xFF94A3B8);
            tvTime.setTextSize(12);
            topRow.addView(tvTime);
            item.addView(topRow);

            // Distribution details (fixed sequence)
            if (op.getTotalCards() > 0) {
                TextView tvSeq = new TextView(this);
                tvSeq.setText("الكروت (100-200-250-500): " + op.getCardsSequence() + " (المجموع: " + op.getTotalCards() + ")");
                tvSeq.setTextColor(0xFF38BDF8);
                tvSeq.setTextSize(13);
                tvSeq.setPadding(0, 6, 0, 0);
                item.addView(tvSeq);
            }

            // Collection details
            if (op.getCollectedAmount() > 0) {
                TextView tvCol = new TextView(this);
                tvCol.setText("💰 المبلغ المحصل: " + String.format(java.util.Locale.US, "%,.0f", op.getCollectedAmount()) + " ريال");
                tvCol.setTextColor(0xFF34D399);
                tvCol.setTextSize(14);
                tvCol.setTypeface(null, android.graphics.Typeface.BOLD);
                tvCol.setPadding(0, 4, 0, 0);
                item.addView(tvCol);
            }

            if (op.getNotes() != null && !op.getNotes().isEmpty()) {
                TextView tvN = new TextView(this);
                tvN.setText("ملاحظة: " + op.getNotes());
                tvN.setTextColor(0xFF64748B);
                tvN.setTextSize(12);
                item.addView(tvN);
            }

            // Delete button
            Button btnDel = new Button(this);
            btnDel.setText("حذف العملية");
            btnDel.setTextSize(11);
            btnDel.setTextColor(0xFFEF4444);
            btnDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new AlertDialog.Builder(HistoryActivity.this)
                            .setTitle("تأكيد الحذف")
                            .setMessage("هل أنت متأكد من حذف هذه العملية؟")
                            .setPositiveButton("نعم، حذف", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dbHelper.deleteOperation(op.getId());
                                    refreshOperations();
                                    Toast.makeText(HistoryActivity.this, "تم حذف العملية", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton("إلغاء", null)
                            .show();
                }
            });
            item.addView(btnDel);

            opsContainer.addView(item);
        }
    }
}
