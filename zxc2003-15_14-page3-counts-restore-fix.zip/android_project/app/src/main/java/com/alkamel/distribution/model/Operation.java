package com.alkamel.distribution.model;

import org.json.JSONException;
import org.json.JSONObject;

public class Operation {
    private long id;
    private long shopId;
    private String shopName;
    private String date; // YYYY-MM-DD
    private String time; // HH:mm:ss
    private String type; // "DISTRIBUTION", "COLLECTION", "BOTH"
    
    // 4 fixed card categories
    private int card100;
    private int card200;
    private int card250;
    private int card500;
    
    private double collectedAmount;
    private String notes;
    private long createdAt;

    public Operation() {
        this.createdAt = System.currentTimeMillis();
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getShopId() { return shopId; }
    public void setShopId(long shopId) { this.shopId = shopId; }

    public String getShopName() { return shopName; }
    public void setShopName(String shopName) { this.shopName = shopName; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public int getCard100() { return card100; }
    public void setCard100(int card100) { this.card100 = card100; }

    public int getCard200() { return card200; }
    public void setCard200(int card200) { this.card200 = card200; }

    public int getCard250() { return card250; }
    public void setCard250(int card250) { this.card250 = card250; }

    public int getCard500() { return card500; }
    public void setCard500(int card500) { this.card500 = card500; }

    public int getTotalCards() {
        return card100 + card200 + card250 + card500;
    }

    public double getCollectedAmount() { return collectedAmount; }
    public void setCollectedAmount(double collectedAmount) { this.collectedAmount = collectedAmount; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    public String getCardsSequence() {
        return card100 + "-" + card200 + "-" + card250 + "-" + card500;
    }

    public JSONObject toJSON() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("id", id);
        obj.put("shopId", shopId);
        obj.put("shopName", shopName != null ? shopName : "");
        obj.put("date", date != null ? date : "");
        obj.put("time", time != null ? time : "");
        obj.put("type", type != null ? type : "");
        obj.put("card100", card100);
        obj.put("card200", card200);
        obj.put("card250", card250);
        obj.put("card500", card500);
        obj.put("collectedAmount", collectedAmount);
        obj.put("notes", notes != null ? notes : "");
        obj.put("createdAt", createdAt);
        return obj;
    }

    public static Operation fromJSON(JSONObject obj) throws JSONException {
        Operation op = new Operation();
        if (obj.has("id")) op.setId(obj.getLong("id"));
        op.setShopId(obj.optLong("shopId", 0));
        op.setShopName(obj.optString("shopName", ""));
        op.setDate(obj.optString("date", ""));
        op.setTime(obj.optString("time", ""));
        op.setType(obj.optString("type", "DISTRIBUTION"));
        op.setCard100(obj.optInt("card100", 0));
        op.setCard200(obj.optInt("card200", 0));
        op.setCard250(obj.optInt("card250", 0));
        op.setCard500(obj.optInt("card500", 0));
        op.setCollectedAmount(obj.optDouble("collectedAmount", 0.0));
        op.setNotes(obj.optString("notes", ""));
        op.setCreatedAt(obj.optLong("createdAt", System.currentTimeMillis()));
        return op;
    }
}
