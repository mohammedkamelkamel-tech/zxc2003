package com.alkamel.distribution.model;

import org.json.JSONException;
import org.json.JSONObject;

public class Shop {
    private long id;
    private String name;
    private String ownerName;
    private String phone;
    private String address;
    private String notes;
    private boolean isActive;
    private long createdAt;

    public Shop() {
        this.isActive = true;
        this.createdAt = System.currentTimeMillis();
    }

    public Shop(String name, String ownerName, String phone, String address, String notes) {
        this.name = name;
        this.ownerName = ownerName;
        this.phone = phone;
        this.address = address;
        this.notes = notes;
        this.isActive = true;
        this.createdAt = System.currentTimeMillis();
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    public JSONObject toJSON() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("id", id);
        obj.put("name", name != null ? name : "");
        obj.put("ownerName", ownerName != null ? ownerName : "");
        obj.put("phone", phone != null ? phone : "");
        obj.put("address", address != null ? address : "");
        obj.put("notes", notes != null ? notes : "");
        obj.put("isActive", isActive);
        obj.put("createdAt", createdAt);
        return obj;
    }

    public static Shop fromJSON(JSONObject obj) throws JSONException {
        Shop s = new Shop();
        if (obj.has("id")) s.setId(obj.getLong("id"));
        s.setName(obj.optString("name", ""));
        s.setOwnerName(obj.optString("ownerName", ""));
        s.setPhone(obj.optString("phone", ""));
        s.setAddress(obj.optString("address", ""));
        s.setNotes(obj.optString("notes", ""));
        s.setActive(obj.optBoolean("isActive", true));
        s.setCreatedAt(obj.optLong("createdAt", System.currentTimeMillis()));
        return s;
    }
}
