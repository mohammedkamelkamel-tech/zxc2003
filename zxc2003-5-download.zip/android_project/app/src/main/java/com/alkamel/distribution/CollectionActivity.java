package com.alkamel.distribution;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.alkamel.distribution.database.DatabaseHelper;
import com.alkamel.distribution.model.Operation;
import com.alkamel.distribution.model.Shop;
import com.alkamel.distribution.util.DateUtils;

import java.util.ArrayList;
import java.util.List;

public class CollectionActivity extends Activity {
    private DatabaseHelper dbHelper;
    private Spinner spShops;
    private List<Shop> shopsList;
    private EditText etAmount;
    private EditText etNotes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = DatabaseHelper.getInstance(this);
        setTitle("تسجيل عملية تحصيل مالي");
        initUI();
    }

    private void initUI() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scrollView.setBackgroundColor(0xFF0F172A);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 40);
        scrollView.addView(root);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("💰 تحصيل مبالغ مالية مستقل");
        tvTitle.setTextSize(20);
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(tvTitle);

        TextView tvSub = new TextView(this);
        tvSub.setText("التحصيل مستقل تماماً عن التوزيع - سداد ديون سابقة أو دفعات نقدية دون توزيع كروت");
        tvSub.setTextColor(0xFF38BDF8);
        tvSub.setTextSize(13);
        tvSub.setPadding(0, 8, 0, 20);
        root.addView(tvSub);

        // Shop Selection
        TextView tvShopLabel = new TextView(this);
        tvShopLabel.setText("اختر المحل:");
        tvShopLabel.setTextColor(0xFF94A3B8);
        tvShopLabel.setPadding(0, 8, 0, 8);
        root.addView(tvShopLabel);

        spShops = new Spinner(this);
        spShops.setBackgroundColor(0xFF1E293B);
        spShops.setPadding(12, 12, 12, 12);
        root.addView(spShops);

        loadShopsSpinner();

        // Amount Input
        TextView tvAmountLabel = new TextView(this);
        tvAmountLabel.setText("المبلغ المحصل فعلياً (ريال):");
        tvAmountLabel.setTextColor(0xFF34D399);
        tvAmountLabel.setTextSize(16);
        tvAmountLabel.setTypeface(null, android.graphics.Typeface.BOLD);
        tvAmountLabel.setPadding(0, 24, 0, 8);
        root.addView(tvAmountLabel);

        etAmount = new EditText(this);
        etAmount.setHint("مثال: 50000");
        etAmount.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etAmount.setTextColor(Color.WHITE);
        etAmount.setBackgroundColor(0xFF1E293B);
        etAmount.setTextSize(20);
        etAmount.setPadding(16, 16, 16, 16);
        root.addView(etAmount);

        // Notes
        TextView tvNotesLabel = new TextView(this);
        tvNotesLabel.setText("ملاحظات (مثلاً: دفعة سابقة، سداد دين، كاش):");
        tvNotesLabel.setTextColor(0xFF94A3B8);
        tvNotesLabel.setPadding(0, 16, 0, 8);
        root.addView(tvNotesLabel);

        etNotes = new EditText(this);
        etNotes.setHint("ملاحظات التحصيل...");
        etNotes.setTextColor(Color.WHITE);
        etNotes.setBackgroundColor(0xFF1E293B);
        etNotes.setPadding(16, 16, 16, 16);
        root.addView(etNotes);

        // Save Button
        Button btnSave = new Button(this);
        btnSave.setText("💰 حفظ مبلغ التحصيل");
        btnSave.setTextSize(18);
        btnSave.setTextColor(Color.WHITE);
        btnSave.setBackgroundColor(0xFFD97706); // amber-600
        btnSave.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnParams.setMargins(0, 30, 0, 20);
        btnSave.setLayoutParams(btnParams);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCollection();
            }
        });
        root.addView(btnSave);

        setContentView(scrollView);
    }

    private void loadShopsSpinner() {
        shopsList = dbHelper.getAllShops(null, true);
        List<String> names = new ArrayList<String>();
        if (shopsList.isEmpty()) {
            names.add("لا توجد محلات نشطة");
        } else {
            for (Shop s : shopsList) {
                names.add(s.getName());
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, names);
        spShops.setAdapter(adapter);
    }

    private void saveCollection() {
        if (shopsList.isEmpty()) {
            Toast.makeText(this, "يرجى إضافة محل أولاً", Toast.LENGTH_SHORT).show();
            return;
        }

        String strAmount = etAmount.getText().toString().trim();
        if (strAmount.isEmpty()) {
            Toast.makeText(this, "يرجى إدخال المبلغ المحصل", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = 0;
        try {
            amount = Double.parseDouble(strAmount);
        } catch (Exception e) {
            Toast.makeText(this, "المبلغ المدخل غير صالح", Toast.LENGTH_SHORT).show();
            return;
        }

        if (amount <= 0) {
            Toast.makeText(this, "يجب أن يكون المبلغ أكبر من صفر", Toast.LENGTH_SHORT).show();
            return;
        }

        Shop selectedShop = shopsList.get(spShops.getSelectedItemPosition());

        Operation op = new Operation();
        op.setShopId(selectedShop.getId());
        op.setShopName(selectedShop.getName());
        op.setDate(DateUtils.getTodayDate());
        op.setTime(DateUtils.getCurrentTime());
        op.setType("COLLECTION");
        op.setCollectedAmount(amount);
        op.setNotes(etNotes.getText().toString().trim());

        dbHelper.insertOperation(op);
        Toast.makeText(this, "تم حفظ مبلغ التحصيل: " + String.format(java.util.Locale.US, "%,.0f", amount) + " ريال", Toast.LENGTH_LONG).show();
        finish();
    }
}
