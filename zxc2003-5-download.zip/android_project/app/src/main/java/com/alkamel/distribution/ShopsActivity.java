package com.alkamel.distribution;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.alkamel.distribution.database.DatabaseHelper;
import com.alkamel.distribution.model.Shop;

import java.util.List;

public class ShopsActivity extends Activity {
    private DatabaseHelper dbHelper;
    private LinearLayout listContainer;
    private EditText etSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = DatabaseHelper.getInstance(this);
        setTitle("إدارة المحلات والبقالات");
        initUI();
    }

    private void initUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0F172A);
        root.setPadding(20, 20, 20, 20);

        // Top bar with Add Button
        Button btnAdd = new Button(this);
        btnAdd.setText("➕ إضافة محل / بقالة جديدة");
        btnAdd.setTextSize(16);
        btnAdd.setTextColor(Color.WHITE);
        btnAdd.setBackgroundColor(0xFF2563EB);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showShopDialog(null);
            }
        });
        root.addView(btnAdd);

        // Search Input
        etSearch = new EditText(this);
        etSearch.setHint("🔍 ابحث عن اسم المحل...");
        etSearch.setHintTextColor(0xFF64748B);
        etSearch.setTextColor(Color.WHITE);
        etSearch.setBackgroundColor(0xFF1E293B);
        etSearch.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        searchParams.setMargins(0, 16, 0, 16);
        etSearch.setLayoutParams(searchParams);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                refreshList();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
        root.addView(etSearch);

        // ScrollView with Shops
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(listContainer);

        root.addView(scrollView);
        setContentView(root);

        refreshList();
    }

    private void refreshList() {
        listContainer.removeAllViews();
        String query = etSearch.getText().toString();
        List<Shop> shops = dbHelper.getAllShops(query, false);

        if (shops.isEmpty()) {
            TextView emptyTv = new TextView(this);
            emptyTv.setText("لا توجد محلات مسجلة تطابق البحث");
            emptyTv.setTextColor(0xFF94A3B8);
            emptyTv.setTextSize(15);
            emptyTv.setPadding(20, 40, 20, 20);
            emptyTv.setGravity(Gravity.CENTER);
            listContainer.addView(emptyTv);
            return;
        }

        for (final Shop s : shops) {
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setBackgroundColor(0xFF1E293B);
            item.setPadding(16, 16, 16, 16);
            LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            itemParams.setMargins(0, 0, 0, 12);
            item.setLayoutParams(itemParams);

            LinearLayout topRow = new LinearLayout(this);
            topRow.setOrientation(LinearLayout.HORIZONTAL);

            TextView tvName = new TextView(this);
            tvName.setText(s.getName());
            tvName.setTextSize(17);
            tvName.setTextColor(Color.WHITE);
            tvName.setTypeface(null, android.graphics.Typeface.BOLD);
            LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
            tvName.setLayoutParams(nameParams);
            topRow.addView(tvName);

            TextView tvStatus = new TextView(this);
            tvStatus.setText(s.isActive() ? "نشط" : "متوقف");
            tvStatus.setTextColor(s.isActive() ? 0xFF10B981 : 0xFFEF4444);
            tvStatus.setTextSize(13);
            topRow.addView(tvStatus);
            item.addView(topRow);

            if (s.getPhone() != null && !s.getPhone().isEmpty()) {
                TextView tvPhone = new TextView(this);
                tvPhone.setText("📞 " + s.getPhone() + (s.getOwnerName() != null && !s.getOwnerName().isEmpty() ? " (" + s.getOwnerName() + ")" : ""));
                tvPhone.setTextColor(0xFF94A3B8);
                tvPhone.setTextSize(13);
                item.addView(tvPhone);
            }

            if (s.getAddress() != null && !s.getAddress().isEmpty()) {
                TextView tvAddr = new TextView(this);
                tvAddr.setText("📍 " + s.getAddress());
                tvAddr.setTextColor(0xFF64748B);
                tvAddr.setTextSize(12);
                item.addView(tvAddr);
            }

            // Buttons row
            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setPadding(0, 10, 0, 0);

            Button btnEdit = new Button(this);
            btnEdit.setText("تعديل");
            btnEdit.setTextSize(12);
            btnEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showShopDialog(s);
                }
            });
            btnRow.addView(btnEdit);

            Button btnToggle = new Button(this);
            btnToggle.setText(s.isActive() ? "إيقاف" : "تفعيل");
            btnToggle.setTextSize(12);
            btnToggle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    s.setActive(!s.isActive());
                    dbHelper.updateShop(s);
                    refreshList();
                }
            });
            btnRow.addView(btnToggle);

            item.addView(btnRow);
            listContainer.addView(item);
        }
    }

    private void showShopDialog(final Shop shopToEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(shopToEdit == null ? "إضافة محل جديد" : "تعديل بيانات المحل");

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(24, 16, 24, 16);

        final EditText etName = new EditText(this);
        etName.setHint("اسم المحل أو البقالة (إلزامي)");
        if (shopToEdit != null) etName.setText(shopToEdit.getName());
        form.addView(etName);

        final EditText etOwner = new EditText(this);
        etOwner.setHint("اسم صاحب المحل (اختياري)");
        if (shopToEdit != null) etOwner.setText(shopToEdit.getOwnerName());
        form.addView(etOwner);

        final EditText etPhone = new EditText(this);
        etPhone.setHint("رقم الهاتف (اختياري)");
        if (shopToEdit != null) etPhone.setText(shopToEdit.getPhone());
        form.addView(etPhone);

        final EditText etAddress = new EditText(this);
        etAddress.setHint("العنوان (اختياري)");
        if (shopToEdit != null) etAddress.setText(shopToEdit.getAddress());
        form.addView(etAddress);

        final EditText etNotes = new EditText(this);
        etNotes.setHint("ملاحظات إضافية (اختياري)");
        if (shopToEdit != null) etNotes.setText(shopToEdit.getNotes());
        form.addView(etNotes);

        builder.setView(form);

        builder.setPositiveButton("حفظ", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name = etName.getText().toString().trim();
                if (name.isEmpty()) {
                    Toast.makeText(ShopsActivity.this, "يرجى كتابة اسم المحل", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (shopToEdit == null) {
                    Shop s = new Shop(name, etOwner.getText().toString().trim(),
                            etPhone.getText().toString().trim(), etAddress.getText().toString().trim(),
                            etNotes.getText().toString().trim());
                    dbHelper.insertShop(s);
                    Toast.makeText(ShopsActivity.this, "تم إضافة المحل بنجاح", Toast.LENGTH_SHORT).show();
                } else {
                    shopToEdit.setName(name);
                    shopToEdit.setOwnerName(etOwner.getText().toString().trim());
                    shopToEdit.setPhone(etPhone.getText().toString().trim());
                    shopToEdit.setAddress(etAddress.getText().toString().trim());
                    shopToEdit.setNotes(etNotes.getText().toString().trim());
                    dbHelper.updateShop(shopToEdit);
                    Toast.makeText(ShopsActivity.this, "تم تحديث البيانات بنجاح", Toast.LENGTH_SHORT).show();
                }
                refreshList();
            }
        });

        builder.setNegativeButton("إلغاء", null);
        builder.show();
    }
}
