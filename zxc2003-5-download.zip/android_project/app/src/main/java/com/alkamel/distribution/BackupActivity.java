package com.alkamel.distribution;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.alkamel.distribution.database.DatabaseHelper;
import com.alkamel.distribution.util.DateUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class BackupActivity extends Activity {
    private DatabaseHelper dbHelper;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = DatabaseHelper.getInstance(this);
        setTitle("النسخ الاحتياطي واستعادة البيانات");
        initUI();
    }

    private void initUI() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scrollView.setBackgroundColor(0xFF0F172A);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 40);
        scrollView.addView(root);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("💾 النسخ الاحتياطي والاستعادة المحلية");
        tvTitle.setTextSize(20);
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(tvTitle);

        TextView tvDesc = new TextView(this);
        tvDesc.setText("يعمل النسخ الاحتياطي محلياً وبدون إنترنت لحماية كافة بيانات المحلات والعمليات.");
        tvDesc.setTextColor(0xFF94A3B8);
        tvDesc.setTextSize(13);
        tvDesc.setPadding(0, 8, 0, 24);
        root.addView(tvDesc);

        // Backup Section
        Button btnBackup = new Button(this);
        btnBackup.setText("📤 إنشاء نسخة احتياطية جديدة الآن");
        btnBackup.setTextSize(16);
        btnBackup.setTextColor(Color.WHITE);
        btnBackup.setBackgroundColor(0xFF059669);
        btnBackup.setPadding(20, 20, 20, 20);
        btnBackup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createBackup();
            }
        });
        root.addView(btnBackup);

        // Restore Section
        Button btnRestore = new Button(this);
        btnRestore.setText("📥 استعادة البيانات من نسخة سابقة");
        btnRestore.setTextSize(16);
        btnRestore.setTextColor(Color.WHITE);
        btnRestore.setBackgroundColor(0xFF2563EB);
        btnRestore.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.setMargins(0, 16, 0, 24);
        btnRestore.setLayoutParams(rp);
        btnRestore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRestoreDialog();
            }
        });
        root.addView(btnRestore);

        tvStatus = new TextView(this);
        tvStatus.setTextColor(0xFF38BDF8);
        tvStatus.setTextSize(13);
        tvStatus.setPadding(0, 10, 0, 10);
        root.addView(tvStatus);

        setContentView(scrollView);
    }

    private void createBackup() {
        try {
            String json = dbHelper.exportBackupJSON();
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists()) dir.mkdirs();
            String fileName = "alkamel_backup_" + DateUtils.getTodayDate() + "_" + System.currentTimeMillis() + ".json";
            File backupFile = new File(dir, fileName);

            FileOutputStream fos = new FileOutputStream(backupFile);
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            osw.write(json);
            osw.close();
            fos.close();

            tvStatus.setText("تم إنشاء النسخة الاحتياطية بنجاح:\n" + backupFile.getAbsolutePath());
            Toast.makeText(this, "تم إنشاء النسخة الاحتياطية بنجاح!", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            tvStatus.setText("فشل النسخ الاحتياطي: " + e.getMessage());
            Toast.makeText(this, "خطأ: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showRestoreDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("تحذير قبل الاستعادة");
        builder.setMessage("استعادة البيانات ستستبدل البيانات الحالية بالنسخة المحددة. أدخل مسار الملف أو اسم الملف في مجلد التنزيلات:");

        final EditText etFilePath = new EditText(this);
        etFilePath.setHint("اسم ملف النسخة الاحتياطية (.json)");
        builder.setView(etFilePath);

        builder.setPositiveButton("استعادة وتحقق", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String input = etFilePath.getText().toString().trim();
                if (input.isEmpty()) {
                    Toast.makeText(BackupActivity.this, "يرجى تحديد الملف", Toast.LENGTH_SHORT).show();
                    return;
                }
                restoreFromFile(input);
            }
        });
        builder.setNegativeButton("إلغاء", null);
        builder.show();
    }

    private void restoreFromFile(String filePath) {
        File f = new File(filePath);
        if (!f.exists()) {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            f = new File(dir, filePath);
        }

        if (!f.exists()) {
            Toast.makeText(this, "الملف غير موجود!", Toast.LENGTH_LONG).show();
            return;
        }

        try {
            FileInputStream fis = new FileInputStream(f);
            BufferedReader br = new BufferedReader(new InputStreamReader(fis, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
            fis.close();

            boolean success = dbHelper.importBackupJSON(sb.toString());
            if (success) {
                tvStatus.setText("تمت استعادة البيانات بنجاح والتحقق من سلامة الجداول.");
                Toast.makeText(this, "تمت الاستعادة بنجاح!", Toast.LENGTH_LONG).show();
            } else {
                tvStatus.setText("فشلت الاستعادة: صيغة الملف غير صحيحة أو تالفة.");
                Toast.makeText(this, "ملف النسخة الاحتياطية غير صالح!", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            tvStatus.setText("خطأ أثناء قراءة الملف: " + e.getMessage());
            Toast.makeText(this, "خطأ: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
