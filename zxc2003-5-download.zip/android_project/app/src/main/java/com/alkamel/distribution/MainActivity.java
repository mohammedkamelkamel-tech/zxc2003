package com.alkamel.distribution;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.alkamel.distribution.database.DatabaseHelper;
import com.alkamel.distribution.model.DailySummary;
import com.alkamel.distribution.util.DateUtils;

public class MainActivity extends Activity {
    private DatabaseHelper dbHelper;
    private TextView tvTodayDate;
    private TextView tvStatC100, tvStatC200, tvStatC250, tvStatC500;
    private TextView tvTotalCards, tvTotalAmount, tvVisitedShops;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = DatabaseHelper.getInstance(this);
        initUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshTodayStats();
    }

    private void initUI() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scrollView.setBackgroundColor(0xFF0F172A); // slate-900

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 40);
        scrollView.addView(root);

        // Header with App Icon and Title
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 10, 0, 24);

        ImageView ivLogo = new ImageView(this);
        ivLogo.setImageResource(R.mipmap.ic_launcher);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(120, 120);
        logoParams.setMargins(0, 0, 20, 0);
        ivLogo.setLayoutParams(logoParams);
        header.addView(ivLogo);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        
        TextView tvTitle = new TextView(this);
        tvTitle.setText("الكامل للتوزيع والتحصيل");
        tvTitle.setTextSize(22);
        tvTitle.setTextColor(0xFFF8FAFC);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        titleBox.addView(tvTitle);

        tvTodayDate = new TextView(this);
        tvTodayDate.setTextSize(14);
        tvTodayDate.setTextColor(0xFF94A3B8);
        titleBox.addView(tvTodayDate);

        header.addView(titleBox);
        root.addView(header);

        // Prominent PDF Invoice Button
        Button btnPdf = new Button(this);
        btnPdf.setText("📄 إنشاء فاتورة اليوم PDF");
        btnPdf.setTextSize(18);
        btnPdf.setTextColor(Color.WHITE);
        btnPdf.setBackgroundColor(0xFF2563EB); // blue-600
        btnPdf.setPadding(20, 24, 20, 24);
        LinearLayout.LayoutParams btnPdfParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnPdfParams.setMargins(0, 10, 0, 24);
        btnPdf.setLayoutParams(btnPdfParams);
        btnPdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ReportActivity.class);
                i.putExtra("DATE", DateUtils.getTodayDate());
                startActivity(i);
            }
        });
        root.addView(btnPdf);

        // Today Summary Card
        LinearLayout summaryCard = new LinearLayout(this);
        summaryCard.setOrientation(LinearLayout.VERTICAL);
        summaryCard.setBackgroundColor(0xFF1E293B);
        summaryCard.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, 24);
        summaryCard.setLayoutParams(cardParams);

        TextView tvSummaryHeader = new TextView(this);
        tvSummaryHeader.setText("📊 ملخص توزيع وتحصيل اليوم");
        tvSummaryHeader.setTextSize(16);
        tvSummaryHeader.setTextColor(0xFFFBBF24); // gold
        tvSummaryHeader.setTypeface(null, android.graphics.Typeface.BOLD);
        summaryCard.addView(tvSummaryHeader);

        // 4 cards in a row
        LinearLayout cardsRow = new LinearLayout(this);
        cardsRow.setOrientation(LinearLayout.HORIZONTAL);
        cardsRow.setPadding(0, 16, 0, 16);
        cardsRow.setWeightSum(4);

        tvStatC100 = createCardBox(cardsRow, "100 ريال", 0xFFEF4444);
        tvStatC200 = createCardBox(cardsRow, "200 ريال", 0xFF8B5CF6);
        tvStatC250 = createCardBox(cardsRow, "250 ريال", 0xFF10B981);
        tvStatC500 = createCardBox(cardsRow, "500 ريال", 0xFFF59E0B);
        summaryCard.addView(cardsRow);

        // Totals Row
        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        statsRow.setWeightSum(3);

        tvTotalCards = createStatBox(statsRow, "إجمالي الكروت", "0", 0xFF38BDF8);
        tvTotalAmount = createStatBox(statsRow, "إجمالي التحصيل", "0 ر.ي", 0xFF34D399);
        tvVisitedShops = createStatBox(statsRow, "محلات تمت زيارتها", "0", 0xFFA78BFA);
        summaryCard.addView(statsRow);

        root.addView(summaryCard);

        // Quick Action Buttons Grid
        root.addView(createSectionTitle("⚡ العمليات السريعة"));

        LinearLayout rowActions1 = new LinearLayout(this);
        rowActions1.setOrientation(LinearLayout.HORIZONTAL);
        rowActions1.setWeightSum(2);
        createActionButton(rowActions1, "📦 توزيع كروت", 0xFF059669, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DistributionActivity.class));
            }
        });
        createActionButton(rowActions1, "💰 تحصيل مالي", 0xFFD97706, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CollectionActivity.class));
            }
        });
        root.addView(rowActions1);

        LinearLayout rowActions2 = new LinearLayout(this);
        rowActions2.setOrientation(LinearLayout.HORIZONTAL);
        rowActions2.setWeightSum(2);
        createActionButton(rowActions2, "🏪 إدارة المحلات", 0xFF4F46E5, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ShopsActivity.class));
            }
        });
        createActionButton(rowActions2, "📜 سجل العمليات", 0xFF0284C7, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, HistoryActivity.class));
            }
        });
        root.addView(rowActions2);

        LinearLayout rowActions3 = new LinearLayout(this);
        rowActions3.setOrientation(LinearLayout.HORIZONTAL);
        rowActions3.setWeightSum(2);
        createActionButton(rowActions3, "📈 التقارير", 0xFF7C3AED, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ReportActivity.class));
            }
        });
        createActionButton(rowActions3, "💾 النسخ الاحتياطي", 0xFF475569, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, BackupActivity.class));
            }
        });
        root.addView(rowActions3);

        setContentView(scrollView);
    }

    private TextView createCardBox(LinearLayout parent, String title, int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(color);
        box.setPadding(8, 12, 8, 12);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        params.setMargins(4, 0, 4, 0);
        box.setLayoutParams(params);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(11);
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setGravity(Gravity.CENTER);
        box.addView(tvTitle);

        TextView tvValue = new TextView(this);
        tvValue.setText("0");
        tvValue.setTextSize(16);
        tvValue.setTextColor(Color.WHITE);
        tvValue.setTypeface(null, android.graphics.Typeface.BOLD);
        tvValue.setGravity(Gravity.CENTER);
        box.addView(tvValue);

        parent.addView(box);
        return tvValue;
    }

    private TextView createStatBox(LinearLayout parent, String title, String defVal, int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(4, 10, 4, 10);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        box.setLayoutParams(params);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(12);
        tvTitle.setTextColor(0xFF94A3B8);
        tvTitle.setGravity(Gravity.CENTER);
        box.addView(tvTitle);

        TextView tvValue = new TextView(this);
        tvValue.setText(defVal);
        tvValue.setTextSize(16);
        tvValue.setTextColor(color);
        tvValue.setTypeface(null, android.graphics.Typeface.BOLD);
        tvValue.setGravity(Gravity.CENTER);
        box.addView(tvValue);

        parent.addView(box);
        return tvValue;
    }

    private void createActionButton(LinearLayout parent, String title, int bgColor, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(title);
        btn.setTextSize(15);
        btn.setTextColor(Color.WHITE);
        btn.setBackgroundColor(bgColor);
        btn.setPadding(16, 20, 16, 20);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        params.setMargins(6, 6, 6, 6);
        btn.setLayoutParams(params);
        btn.setOnClickListener(listener);
        parent.addView(btn);
    }

    private TextView createSectionTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setTextColor(0xFFF8FAFC);
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        tv.setPadding(0, 10, 0, 10);
        return tv;
    }

    private void refreshTodayStats() {
        String today = DateUtils.getTodayDate();
        tvTodayDate.setText("تاريخ اليوم: " + today);
        DailySummary summary = dbHelper.getDailySummary(today);

        tvStatC100.setText(String.valueOf(summary.totalCard100));
        tvStatC200.setText(String.valueOf(summary.totalCard200));
        tvStatC250.setText(String.valueOf(summary.totalCard250));
        tvStatC500.setText(String.valueOf(summary.totalCard500));

        tvTotalCards.setText(String.valueOf(summary.getTotalCards()));
        tvTotalAmount.setText(String.format(java.util.Locale.US, "%,.0f", summary.totalCollected) + " ريال");
        tvVisitedShops.setText(String.valueOf(summary.visitedShopsCount));
    }
}
